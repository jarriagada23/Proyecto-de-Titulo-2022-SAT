﻿using Datos;
using Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NegocioDepartamento
    {
        DatosDepartamento datosDepartamento = new DatosDepartamento();
        public bool InsertarDepartamento(ModeloDepartamento departamento)
        {

            return datosDepartamento.InsertarDepartamento(departamento);
        }

        public List<ModeloDepartamento> ListaDepartamento()
        {
            return datosDepartamento.ListaDepartamento();
        }

        public ModeloDepartamento BuscarDepartamento(ModeloDepartamento departamento)
        {
            return datosDepartamento.BuscarDepartamento(departamento);
        }

        public bool EditarDepartamento(ModeloDepartamento departamento)
        {
            return datosDepartamento.EditarDepartamento(departamento);
        }
    }
}
