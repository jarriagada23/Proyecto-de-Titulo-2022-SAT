﻿using Datos;
using Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NegocioRegion
    {
        DatosRegion datosRegion = new DatosRegion();
        public List<ModeloRegion> LeerRegion()
        {
            return datosRegion.LeerRegion();
        }
    }
}
