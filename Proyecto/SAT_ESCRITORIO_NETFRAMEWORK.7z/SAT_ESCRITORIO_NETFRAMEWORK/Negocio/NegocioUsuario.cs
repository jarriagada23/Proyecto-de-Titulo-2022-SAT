﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modelo;
using Datos;

namespace Negocio
{
    public class NegocioUsuario
    {
        DatosUsuario datosUsuario = new DatosUsuario();
        public int validarUsuario(ModeloUsuario usuario)
        {
            return datosUsuario.Login(usuario);
        }

        public bool InsertarUsuario(ModeloUsuario usuario)
        {
            return datosUsuario.InsertarUsuario(usuario);
        }

        public List<ModeloUsuario> ListaUsuario()
        {
            return datosUsuario.ListaUsuario();
        }

        public ModeloUsuario BuscarUsuario(ModeloUsuario usuario)
        {
            return datosUsuario.BuscarUsuario(usuario);
        }

        public bool EditarUsuario(ModeloUsuario usuario)
        {
            return datosUsuario.EditarUsuario(usuario);
        }
    }
}
