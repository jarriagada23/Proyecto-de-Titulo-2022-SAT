﻿using Datos;
using Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NegocioEdificio
    {
        DatosEdificio datosEdificio = new DatosEdificio();
        public bool InsertarEdificio(ModeloEdificio edificio)
        {

            return datosEdificio.InsertarEdificio(edificio);
        }

        public List<ModeloEdificio> ListaEdificio()
        {
            return datosEdificio.ListaEdificio();
        }

        public ModeloEdificio BuscarEdificio(ModeloEdificio edificio)
        {
            return datosEdificio.BuscarEdificio(edificio);
        }

        public bool EditarEdificio(ModeloEdificio edificio)
        {
            return datosEdificio.EditarEdificio(edificio);
        }

        public List<ModeloEdificio> ListaEdificioCbo()
        {
            return datosEdificio.ListaEdificioCbo();
        }
    }
}
