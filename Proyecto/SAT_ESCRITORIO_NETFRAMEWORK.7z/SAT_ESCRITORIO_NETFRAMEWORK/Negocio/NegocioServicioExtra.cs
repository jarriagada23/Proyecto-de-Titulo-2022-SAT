﻿using Datos;
using Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NegocioServicioExtra
    {
        DatosServiciosExtra datosServicio = new DatosServiciosExtra();
        public bool InsertarServicio(ModeloServicioExtra servicioExtra)
        {

            return datosServicio.InsertarServicioExtra(servicioExtra);
        }

        public List<ModeloServicioExtra> ListaServicio()
        {
            return datosServicio.ListaServicioExtra();
        }

        public ModeloServicioExtra BuscarServicio(ModeloServicioExtra servicioExtra)
        {
            return datosServicio.BuscarServicio(servicioExtra);
        }

        public bool EditarServicio(ModeloServicioExtra servicioExtra)
        {
            return datosServicio.EditarServicio(servicioExtra);
        }

    }
}
