﻿using Datos;
using Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    public class NegocioComuna
    {
        DatosComuna datosComuna = new DatosComuna();
        public List<ModeloComuna> LeerComuna(ModeloRegion region)
        {
            return datosComuna.LeerComuna(region);
        }
    }
}
