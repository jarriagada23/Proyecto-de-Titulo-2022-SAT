﻿using Modelo;
using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    public partial class VistaMantenedorUsuario : Form
    {
        public VistaMantenedorUsuario()
        {
            InitializeComponent();
        }

        private void VistaMantenedorUsuario_Load(object sender, EventArgs e)
        {
            LlenarCboRegion();
            CargarDgvUsuario();
        }

        public void LlenarCboRegion()
        {
            NegocioRegion negocioRegion = new NegocioRegion();
            List<ModeloRegion> datosRegion = negocioRegion.LeerRegion();
            datosRegion.Insert(0, new ModeloRegion(0, "Seleccione Región"));
            cboRegion.ValueMember = "id_region";
            cboRegion.DisplayMember = "nombre_region";
            cboRegion.DataSource = datosRegion;
        }

        public void LlenarCboComuna(int idRegion)
        {
            NegocioComuna negocioComuna = new NegocioComuna();
            ModeloRegion region = new ModeloRegion();
            region.id_region = idRegion;
            List<ModeloComuna> datosComuna = negocioComuna.LeerComuna(region);

            datosComuna.Insert(0, new ModeloComuna(0, "Seleccione Comuna"));
            cboComuna.DataSource = datosComuna;
            cboComuna.ValueMember = "id_comuna";
            cboComuna.DisplayMember = "nombre_comuna";
        }

        private void cboRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboRegion.SelectedIndex != 0)
            {
                int idRegion = Convert.ToInt32(cboRegion.SelectedValue);
                if (idRegion != 0)
                {
                    LlenarCboComuna(idRegion);
                }
                else
                {
                }
            }
            else
            {
                cboComuna.DataSource = null;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtRut.Text.Trim()))
            {
                if (!String.IsNullOrEmpty(txtDv.Text.Trim()))
                {
                    if (ValidaRut(txtRut.Text,txtDv.Text))
                    {
                        if (!String.IsNullOrEmpty(txtNombre.Text.Trim()))
                        {
                            if (!String.IsNullOrEmpty(txtApPaterno.Text.Trim()))
                            {
                                if (!String.IsNullOrEmpty(txtApMaterno.Text.Trim()))
                                {
                                    if (!String.IsNullOrEmpty(txtEmail.Text.Trim()))
                                    {
                                        if (ComprobarFormatoEmail(txtEmail.Text.Trim()))
                                        {
                                            if (!String.IsNullOrEmpty(txtDireccion.Text.Trim()))
                                            {
                                                if (Convert.ToDateTime(dtpFechaNacimiento.Text) < DateTime.Now.Date)
                                                {
                                                    if (!String.IsNullOrEmpty(txtTelefono.Text.Trim()))
                                                    {
                                                        if (cboRegion.SelectedIndex != 0)
                                                        {
                                                            if (cboComuna.SelectedIndex != 0)
                                                            {
                                                                if (!String.IsNullOrEmpty(txtUsuario.Text.Trim()))
                                                                {
                                                                    if (!String.IsNullOrEmpty(txtContraseña.Text.Trim()))
                                                                    {
                                                                        ModeloUsuario modeloUsuario = new ModeloUsuario();
                                                                        NegocioUsuario negocioUsuario = new NegocioUsuario();
                                                                        modeloUsuario.rut = Convert.ToInt32(txtRut.Text);
                                                                        modeloUsuario.dv = txtDv.Text;
                                                                        modeloUsuario.nombre = txtNombre.Text;
                                                                        modeloUsuario.ap_paterno = txtApPaterno.Text;
                                                                        modeloUsuario.ap_materno = txtApMaterno.Text;
                                                                        modeloUsuario.email = txtEmail.Text;
                                                                        modeloUsuario.direccion = txtDireccion.Text;
                                                                        modeloUsuario.usuario = txtUsuario.Text;
                                                                        modeloUsuario.contraseña = txtContraseña.Text;
                                                                        modeloUsuario.fch_nacimiento = Convert.ToDateTime(dtpFechaNacimiento.Text);
                                                                        modeloUsuario.telefono = Convert.ToInt32(txtTelefono.Text);
                                                                        modeloUsuario.region = cboRegion.SelectedValue.ToString();
                                                                        modeloUsuario.comuna = cboComuna.SelectedValue.ToString();
                                                                        modeloUsuario.estado = Convert.ToInt32(chbRegistro.Checked);
                                                                        modeloUsuario.id_rol = 3;

                                                                        bool respuesta = negocioUsuario.InsertarUsuario(modeloUsuario);
                                                                        if (respuesta == true)
                                                                        {
                                                                            MessageBox.Show("Registros Ingresados Correctamente");
                                                                            txtRut.Clear();
                                                                            txtDv.Clear();
                                                                            txtNombre.Clear();
                                                                            txtApPaterno.Clear();
                                                                            txtApMaterno.Clear();
                                                                            txtEmail.Clear();
                                                                            txtDireccion.Clear();
                                                                            txtUsuario.Clear();
                                                                            txtContraseña.Clear();
                                                                            dtpFechaNacimiento.Value = DateTime.Now.Date;
                                                                            txtTelefono.Clear();
                                                                            cboRegion.SelectedIndex = 0;
                                                                            cboComuna.DataSource = null;
                                                                            chbRegistro.Checked = false;
                                                                            CargarDgvUsuario();
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        MessageBox.Show("Ingrese Contraseña");
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    MessageBox.Show("Ingrese Usuario");
                                                                }
                                                            }
                                                            else
                                                            {
                                                                MessageBox.Show("Seleccione Comuna");
                                                            }
                                                        }
                                                        else
                                                        {
                                                            MessageBox.Show("Seleccione Región");
                                                        }
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show("Ingrese Telefono");
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Seleccione Una Fecha Menor A La Actual");
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Ingrese Dirección");
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Formato de Email Incorrecto");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Ingrese Email");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Ingrese Apellido Materno");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Ingrese Apellido Paterno");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Ingrese Nombre");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Rut Invalido");
                    }
                }
                else
                {
                    MessageBox.Show("Ingrese Digito Verificador");
                }
            }
            else
            {
                MessageBox.Show("Ingrese Rut");
            }
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtRut_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        public static bool ValidaRut(string rut)
        {
            rut = rut.Replace(".", "").ToUpper();
            Regex expresion = new Regex("^([0-9]+-[0-9K])$");
            string dv = rut.Substring(rut.Length - 1, 1);
            if (!expresion.IsMatch(rut))
            {
                return false;
            }
            char[] charCorte = { '-' };
            string[] rutTemp = rut.Split(charCorte);
            if (dv != Digito(int.Parse(rutTemp[0])))
            {
                return false;
            }
            return true;
        }

        public static bool ValidaRut(string rut, string dv)
        {
            return ValidaRut(rut + "-" + dv);
        }

        public static string Digito(int rut)
        {
            int suma = 0;
            int multiplicador = 1;
            while (rut != 0)
            {
                multiplicador++;
                if (multiplicador == 8)
                    multiplicador = 2;
                suma += (rut % 10) * multiplicador;
                rut = rut / 10;
            }
            suma = 11 - (suma % 11);
            if (suma == 11)
            {
                return "0";
            }
            else if (suma == 10)
            {
                return "K";
            }
            else
            {
                return suma.ToString();
            }
        }

        private void txtDv_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar.ToString().ToUpper() != "K")
            {
                e.Handled = true;
            }
        }

        public static bool ComprobarFormatoEmail(string email)
        {
            String sFormato;
            sFormato = "\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
            if (Regex.IsMatch(email, sFormato))
            {
                if (Regex.Replace(email, sFormato, String.Empty).Length == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        private void CargarDgvUsuario()
        {
            NegocioUsuario negocioUsuario = new NegocioUsuario();
            List<ModeloUsuario> listaUsuario = negocioUsuario.ListaUsuario();
            dgvUsuario.DataSource = listaUsuario;
            dgvUsuario.Columns["id_usuario"].HeaderText = "Id Cliente";
            dgvUsuario.Columns["id_usuario"].DisplayIndex = 0;
            dgvUsuario.Columns["rut"].HeaderText = "Rut";
            dgvUsuario.Columns["rut"].DisplayIndex = 1;
            dgvUsuario.Columns["dv"].HeaderText = "Dv";
            dgvUsuario.Columns["dv"].DisplayIndex = 2;
            dgvUsuario.Columns["nombre"].HeaderText = "Nombre";
            dgvUsuario.Columns["nombre"].DisplayIndex = 3;
            dgvUsuario.Columns["ap_paterno"].HeaderText = "Apellido Paterno";
            dgvUsuario.Columns["ap_paterno"].DisplayIndex = 4;
            dgvUsuario.Columns["ap_materno"].HeaderText = "Apellido Materno";
            dgvUsuario.Columns["ap_materno"].DisplayIndex = 5;
            dgvUsuario.Columns["email"].HeaderText = "Email";
            dgvUsuario.Columns["email"].DisplayIndex = 6;
            dgvUsuario.Columns["telefono"].HeaderText = "Telefono";
            dgvUsuario.Columns["telefono"].DisplayIndex = 7;
            dgvUsuario.Columns["region"].HeaderText = "Región";
            dgvUsuario.Columns["region"].DisplayIndex = 8;
            dgvUsuario.Columns["comuna"].HeaderText = "Comuna";
            dgvUsuario.Columns["comuna"].DisplayIndex = 9;
            dgvUsuario.Columns["direccion"].HeaderText = "Dirección";
            dgvUsuario.Columns["direccion"].DisplayIndex = 10;
            dgvUsuario.Columns["fch_nacimiento"].HeaderText = "Fecha Nacimiento";
            dgvUsuario.Columns["fch_nacimiento"].DisplayIndex = 11;
            dgvUsuario.Columns["estado"].HeaderText = "Estado";
            dgvUsuario.Columns["estado"].DisplayIndex = 12;
            dgvUsuario.Columns["usuario"].HeaderText = "Usuario";
            dgvUsuario.Columns["usuario"].DisplayIndex = 13;
            dgvUsuario.Columns["contraseña"].HeaderText = "Contraseña";
            dgvUsuario.Columns["contraseña"].DisplayIndex = 14;
            dgvUsuario.Columns["id_rol"].Visible = false;
        }

        private void dgvUsuario_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvUsuario.Columns[e.ColumnIndex].Name == "btnEditar")
            {
                int Id = Convert.ToInt32(dgvUsuario.CurrentRow.Cells["id_usuario"].Value.ToString());
                VistaEditarUsuario vistaEditarUsuario = new VistaEditarUsuario(Id);
                vistaEditarUsuario.ShowDialog();
                CargarDgvUsuario();
            }
        }
    }
}
