﻿using Modelo;
using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    public partial class VistaEditarDepartamento : Form
    {
        int varIdDepartamento = 0;
        public VistaEditarDepartamento(int idDepartamento)
        {
            InitializeComponent();
            varIdDepartamento = idDepartamento;
            buscarDepartamento(idDepartamento);
        }

        public void LlenarCboEdificio()
        {
            List<ModeloEdificio> datosEdificio = DatosEdificio();
            datosEdificio.Insert(0, new ModeloEdificio(0, "Seleccione Edificio"));
            cboEdificio.ValueMember = "id_edificio";
            cboEdificio.DisplayMember = "nombre_edificio";
            cboEdificio.DataSource = datosEdificio;
        }

        private List<ModeloEdificio> DatosEdificio()
        {
            NegocioEdificio negocioEdificio = new NegocioEdificio();
            return negocioEdificio.ListaEdificioCbo();
        }

        public void LlenarCboNivelPiso(int idEdificio)
        {
            NegocioEdificio negocioEdificio = new NegocioEdificio();
            ModeloEdificio modeloEdificio = new ModeloEdificio();
            modeloEdificio.id_edificio = idEdificio;
            ModeloEdificio datosEdificio = negocioEdificio.BuscarEdificio(modeloEdificio);
            int cantPiso = datosEdificio.cantidad_pisos;
            cboNivelPiso.Items.Insert(0, "Seleccione Nivel");
            for (int i = 1; i <= cantPiso; i++)
            {
                cboNivelPiso.Items.Add(i);
            }

            cboNivelPiso.SelectedIndex = 0;
        }

        private void buscarDepartamento(int idDepartamento)
        {
            NegocioDepartamento negocioDepartamento = new NegocioDepartamento();
            ModeloDepartamento modeloDepartamento = new ModeloDepartamento();
            modeloDepartamento.id_departamento = idDepartamento;
            ModeloDepartamento datosDepartamento = negocioDepartamento.BuscarDepartamento(modeloDepartamento);
            LlenarCboEdificio();
            List<ModeloEdificio> datosEdificio = DatosEdificio();
            int idEdificio = 0;
            foreach (var item in datosEdificio)
            {
                if (item.nombre_edificio == datosDepartamento.edificio)
                {
                    idEdificio = item.id_edificio;
                }
            }
            LlenarCboNivelPiso(idEdificio);
            cboEdificio.SelectedValue = idEdificio;
            cboNivelPiso.SelectedIndex = datosDepartamento.nivel_piso;
            txtNumDepartamento.Text = datosDepartamento.num_departamento;
            txtCantidadHabitaciones.Text = datosDepartamento.cantidad_habitaciones.ToString();
            txtCantidadDeBaños.Text = datosDepartamento.cantidad_baños.ToString();
            chbRegistro.Checked = Convert.ToBoolean(datosDepartamento.estado_registro);

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cboEdificio_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboNivelPiso.Items.Clear();
            if (cboEdificio.SelectedIndex != 0)
            {
                int idEdificio = Convert.ToInt32(cboEdificio.SelectedValue);
                if (idEdificio != 0)
                {
                    LlenarCboNivelPiso(idEdificio);
                }
                else
                {

                }
            }
            else
            {
                cboNivelPiso.Items.Clear();
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (cboEdificio.SelectedIndex != 0)
            {
                if (cboNivelPiso.SelectedIndex != 0)
                {
                    if (!String.IsNullOrEmpty(txtNumDepartamento.Text.Trim()))
                    {
                        if (!String.IsNullOrEmpty(txtCantidadHabitaciones.Text.Trim()))
                        {
                            if (!String.IsNullOrEmpty(txtCantidadDeBaños.Text.Trim()))
                            {
                                ModeloDepartamento modeloDepartamento = new ModeloDepartamento();
                                NegocioDepartamento negocioDepartamento = new NegocioDepartamento();
                                modeloDepartamento.id_departamento = varIdDepartamento;
                                modeloDepartamento.edificio = cboEdificio.SelectedValue.ToString();
                                modeloDepartamento.nivel_piso = Convert.ToInt32(cboNivelPiso.SelectedItem);
                                modeloDepartamento.num_departamento = txtCantidadHabitaciones.Text.Trim();
                                modeloDepartamento.cantidad_habitaciones = Convert.ToInt32(txtCantidadHabitaciones.Text.Trim());
                                modeloDepartamento.cantidad_baños = Convert.ToInt32(txtCantidadDeBaños.Text.Trim());
                                modeloDepartamento.estado_registro = Convert.ToInt32(chbRegistro.Checked);
                                bool respuesta = negocioDepartamento.EditarDepartamento(modeloDepartamento);
                                if (respuesta == true)
                                {
                                    MessageBox.Show("Registros Modificados Correctamente");
                                    //cboEdificio.SelectedIndex = 0;
                                    //cboNivelPiso.Items.Clear();
                                    //cboNivelPiso.Text = "";
                                    //txtNumDepartamento.Clear();
                                    //txtCantidadHabitaciones.Clear();
                                    //txtCantidadDeBaños.Clear();
                                    //chbRegistro.Checked = false;
                                    this.Close();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Ingrese Cantidad de Baños");

                            }
                        }
                        else
                        {
                            MessageBox.Show("Ingrese Cantidad de Habitaciones");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Ingrese Número de Departamento");
                    }
                }
                else
                {
                    MessageBox.Show("Seleccione Nivel de Piso");
                }
            }
            else
            {
                MessageBox.Show("Seleccione Edificio");
            }
        }
    }
}
