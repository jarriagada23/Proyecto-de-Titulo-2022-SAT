﻿using Modelo;
using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    public partial class VistaEditarServicioExtra : Form
    {
        int varIdServicio = 0;
        public VistaEditarServicioExtra(int idServicio)
        {
            InitializeComponent();
            varIdServicio = idServicio;
            buscarServicio(idServicio);
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buscarServicio(int idServicio)
        {
            NegocioServicioExtra negocioServicioExtra = new NegocioServicioExtra();
            ModeloServicioExtra modeloServicioExtra = new ModeloServicioExtra();
            modeloServicioExtra.idServicio = idServicio;
            ModeloServicioExtra datosServicio = negocioServicioExtra.BuscarServicio(modeloServicioExtra);

            txtNombreServicio.Text = datosServicio.nombreServicio;
            txtCostoServicio.Text = datosServicio.costoServicio.ToString();
            txtDescripcion.Text = datosServicio.descripcion;
            chbRegistro.Checked = Convert.ToBoolean(datosServicio.estado);

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtNombreServicio.Text.Trim()))
            {
                if (!String.IsNullOrEmpty(txtCostoServicio.Text.Trim()))
                {
                    ModeloServicioExtra modeloServicio = new ModeloServicioExtra();
                    NegocioServicioExtra negocioServicio = new NegocioServicioExtra();
                    modeloServicio.idServicio = varIdServicio;
                    modeloServicio.nombreServicio = txtNombreServicio.Text;
                    modeloServicio.costoServicio = Convert.ToInt32(txtCostoServicio.Text);
                    modeloServicio.descripcion = txtDescripcion.Text;
                    modeloServicio.estado = Convert.ToInt32(chbRegistro.Checked);

                    bool respuesta = negocioServicio.EditarServicio(modeloServicio);
                    if (respuesta == true)
                    {
                        MessageBox.Show("Registros Modificados Correctamente");
                        txtNombreServicio.Clear();
                        txtCostoServicio.Clear();
                        txtDescripcion.Clear();
                        chbRegistro.Checked = false;
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Ingrese Costo del Servicio");
                }
            }
            else
            {
                MessageBox.Show("Ingrese Nombre del Servicio");
            }
        }
    }
}
