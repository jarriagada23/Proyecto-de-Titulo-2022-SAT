﻿using Modelo;
using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    public partial class VistaMantenedorDepartamento : Form
    {
        public VistaMantenedorDepartamento()
        {
            InitializeComponent();
        }

        public void LlenarCboEdificio()
        {
            NegocioEdificio negocioEdificio = new NegocioEdificio();
            List<ModeloEdificio> datosEdificio = negocioEdificio.ListaEdificioCbo();
            datosEdificio.Insert(0, new ModeloEdificio(0, "Seleccione Edificio"));
            cboEdificio.ValueMember = "id_edificio";
            cboEdificio.DisplayMember = "nombre_edificio";
            cboEdificio.DataSource = datosEdificio;
        }

        public void LlenarCboNivelPiso(int idEdificio)
        {
            NegocioEdificio negocioEdificio = new NegocioEdificio();
            ModeloEdificio modeloEdificio = new ModeloEdificio();
            modeloEdificio.id_edificio = idEdificio;
            ModeloEdificio datosEdificio = negocioEdificio.BuscarEdificio(modeloEdificio);
            int cantPiso = datosEdificio.cantidad_pisos;
            cboNivelPiso.Items.Insert(0, "Seleccione Nivel");
            for (int i = 1; i <= cantPiso; i++)
            {
                cboNivelPiso.Items.Add(i);
            }

            cboNivelPiso.SelectedIndex = 0;
        }


        private void VistaMantenedorDepartamento_Load(object sender, EventArgs e)
        {
            LlenarCboEdificio();
            CargarDgvDepartamento();
        }

        private void cboEdificio_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboNivelPiso.Items.Clear();
            if (cboEdificio.SelectedIndex != 0)
            {
                int idEdificio = Convert.ToInt32(cboEdificio.SelectedValue);
                if (idEdificio != 0)
                {
                    LlenarCboNivelPiso(idEdificio);
                }
                else
                {

                }
            }
            else
            {
                cboNivelPiso.Items.Clear();
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (cboEdificio.SelectedIndex != 0)
            {
                if (cboNivelPiso.SelectedIndex != 0)
                {
                    if (!String.IsNullOrEmpty(txtNumDepartamento.Text.Trim()))
                    {
                        if (!String.IsNullOrEmpty(txtCantidadHabitaciones.Text.Trim()))
                        {
                            if (!String.IsNullOrEmpty(txtCantidadDeBaños.Text.Trim()))
                            {
                                ModeloDepartamento modeloDepartamento = new ModeloDepartamento();
                                NegocioDepartamento negocioDepartamento = new NegocioDepartamento();
                                modeloDepartamento.edificio = cboEdificio.SelectedValue.ToString();
                                modeloDepartamento.nivel_piso = Convert.ToInt32(cboNivelPiso.SelectedItem);
                                modeloDepartamento.num_departamento = txtCantidadHabitaciones.Text.Trim();
                                modeloDepartamento.cantidad_habitaciones = Convert.ToInt32(txtCantidadHabitaciones.Text.Trim());
                                modeloDepartamento.cantidad_baños = Convert.ToInt32(txtCantidadDeBaños.Text.Trim());
                                modeloDepartamento.estado_registro = Convert.ToInt32(chbRegistro.Checked);
                                bool respuesta = negocioDepartamento.InsertarDepartamento(modeloDepartamento);
                                if (respuesta == true)
                                {
                                    MessageBox.Show("Registros Ingresados Correctamente");
                                    cboEdificio.SelectedIndex = 0;
                                    cboNivelPiso.Items.Clear();
                                    cboNivelPiso.Text = "";
                                    txtNumDepartamento.Clear();
                                    txtCantidadHabitaciones.Clear();
                                    txtCantidadDeBaños.Clear();
                                    chbRegistro.Checked = false;
                                }

                            }
                            else
                            {
                                MessageBox.Show("Ingrese Cantidad de Baños");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Ingrese Cantidad de Habitaciones");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Ingrese Número de Departamento");
                    }
                }
                else
                {
                    MessageBox.Show("Seleccione Nivel de Piso");
                }
            }
            else
            {
                MessageBox.Show("Seleccione Edificio");
            }
        }

        private void txtCantidadHabitaciones_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtCantidadDeBaños_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void CargarDgvDepartamento()
        {
            NegocioDepartamento negocioDepartamento = new NegocioDepartamento();
            List<ModeloDepartamento> listaDepartamento = negocioDepartamento.ListaDepartamento();
            dgvDepartamento.DataSource = listaDepartamento;
            dgvDepartamento.Columns["id_departamento"].HeaderText = "Id Depto";
            dgvDepartamento.Columns["id_departamento"].DisplayIndex = 0;
            dgvDepartamento.Columns["edificio"].HeaderText = "Edificio";
            dgvDepartamento.Columns["edificio"].DisplayIndex = 1;
            dgvDepartamento.Columns["nivel_piso"].HeaderText = "Nivel Piso";
            dgvDepartamento.Columns["nivel_piso"].DisplayIndex = 2;
            dgvDepartamento.Columns["num_departamento"].HeaderText = "N° Depto";
            dgvDepartamento.Columns["num_departamento"].DisplayIndex = 3;
            dgvDepartamento.Columns["cantidad_habitaciones"].HeaderText = "Cant Habitaciones";
            dgvDepartamento.Columns["cantidad_habitaciones"].DisplayIndex = 4;
            dgvDepartamento.Columns["cantidad_baños"].HeaderText = "Cant baños";
            dgvDepartamento.Columns["cantidad_baños"].DisplayIndex = 5;
            
        }

        private void dgvDepartamento_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvDepartamento.Columns[e.ColumnIndex].Name == "btnEditar")
            {
                int Id = Convert.ToInt32(dgvDepartamento.CurrentRow.Cells["id_departamento"].Value.ToString());
                VistaEditarDepartamento vistaEditarDepartamento = new VistaEditarDepartamento(Id);
                vistaEditarDepartamento.ShowDialog();
                CargarDgvDepartamento();
            }
        }
    }
}
