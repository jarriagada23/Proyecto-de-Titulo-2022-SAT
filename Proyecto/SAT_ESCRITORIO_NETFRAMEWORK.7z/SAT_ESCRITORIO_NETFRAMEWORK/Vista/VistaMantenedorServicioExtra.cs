﻿using Modelo;
using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    public partial class VistaMantenedorServicioExtra : Form
    {
        public VistaMantenedorServicioExtra()
        {
            InitializeComponent();
        }

        private void VistaMantenedorServiciosExtras_Load(object sender, EventArgs e)
        {
            CargarDgvServicio();
        }

        private void txtCostoServicio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtNombreServicio.Text.Trim()))
            {
                if (!String.IsNullOrEmpty(txtCostoServicio.Text.Trim()))
                {
                    ModeloServicioExtra modeloServicio = new ModeloServicioExtra();
                    NegocioServicioExtra negocioServicio = new NegocioServicioExtra();
                    modeloServicio.nombreServicio = txtNombreServicio.Text;
                    modeloServicio.costoServicio = Convert.ToInt32(txtCostoServicio.Text);
                    modeloServicio.descripcion = txtDescripcion.Text;
                    modeloServicio.estado = Convert.ToInt32(chbRegistro.Checked);

                    bool respuesta = negocioServicio.InsertarServicio(modeloServicio);
                    if (respuesta == true)
                    {
                        MessageBox.Show("Registros Ingresados Correctamente");
                        txtNombreServicio.Clear();
                        txtCostoServicio.Clear();
                        txtDescripcion.Clear();
                        chbRegistro.Checked = false;
                        CargarDgvServicio();
                    }
                }
                else
                {
                    MessageBox.Show("Ingrese Costo del Servicio");
                }
            }
            else
            {
                MessageBox.Show("Ingrese Nombre del Servicio");
            }
        }

        private void CargarDgvServicio()
        {
            NegocioServicioExtra negocioServicio = new NegocioServicioExtra();
            List<ModeloServicioExtra> listaServicio = negocioServicio.ListaServicio();
            dgvServicioExtra.DataSource = listaServicio;
            dgvServicioExtra.Columns["idServicio"].HeaderText = "Id Servicio";
            dgvServicioExtra.Columns["idServicio"].DisplayIndex = 0;
            dgvServicioExtra.Columns["nombreServicio"].HeaderText = "Nombre Servicio";
            dgvServicioExtra.Columns["nombreServicio"].DisplayIndex = 1;
            dgvServicioExtra.Columns["costoServicio"].HeaderText = "Costo Servicio";
            dgvServicioExtra.Columns["costoServicio"].DisplayIndex = 2;
            dgvServicioExtra.Columns["descripcion"].HeaderText = "Descripción";
            dgvServicioExtra.Columns["descripcion"].DisplayIndex = 3;

        }

        private void dgvServicioExtra_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvServicioExtra.Columns[e.ColumnIndex].Name == "btnEditar")
            {
                int Id = Convert.ToInt32(dgvServicioExtra.CurrentRow.Cells["idServicio"].Value.ToString());
                VistaEditarServicioExtra vistaEditarServicioExtra = new VistaEditarServicioExtra(Id);
                vistaEditarServicioExtra.ShowDialog();
                CargarDgvServicio();
            }
        }
    }
}
