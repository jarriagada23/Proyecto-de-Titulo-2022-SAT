﻿namespace Vista
{
    partial class VistaMantenedorServicioExtra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGuardar = new System.Windows.Forms.Button();
            this.dgvServicioExtra = new System.Windows.Forms.DataGridView();
            this.chbRegistro = new System.Windows.Forms.CheckBox();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtNombreServicio = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtCostoServicio = new System.Windows.Forms.TextBox();
            this.chbDgEstado = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.btnEditar = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvServicioExtra)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGuardar
            // 
            this.btnGuardar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGuardar.Location = new System.Drawing.Point(487, 192);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(109, 32);
            this.btnGuardar.TabIndex = 41;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // dgvServicioExtra
            // 
            this.dgvServicioExtra.AllowUserToAddRows = false;
            this.dgvServicioExtra.AllowUserToDeleteRows = false;
            this.dgvServicioExtra.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dgvServicioExtra.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvServicioExtra.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvServicioExtra.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvServicioExtra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvServicioExtra.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chbDgEstado,
            this.btnEditar});
            this.dgvServicioExtra.Location = new System.Drawing.Point(21, 239);
            this.dgvServicioExtra.MultiSelect = false;
            this.dgvServicioExtra.Name = "dgvServicioExtra";
            this.dgvServicioExtra.ReadOnly = true;
            this.dgvServicioExtra.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgvServicioExtra.RowTemplate.Height = 24;
            this.dgvServicioExtra.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvServicioExtra.Size = new System.Drawing.Size(1011, 245);
            this.dgvServicioExtra.TabIndex = 40;
            this.dgvServicioExtra.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvServicioExtra_CellClick);
            // 
            // chbRegistro
            // 
            this.chbRegistro.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chbRegistro.AutoSize = true;
            this.chbRegistro.Location = new System.Drawing.Point(790, 51);
            this.chbRegistro.Name = "chbRegistro";
            this.chbRegistro.Size = new System.Drawing.Size(18, 17);
            this.chbRegistro.TabIndex = 39;
            this.chbRegistro.UseVisualStyleBackColor = true;
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDescripcion.BackColor = System.Drawing.Color.White;
            this.txtDescripcion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDescripcion.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescripcion.ForeColor = System.Drawing.Color.Black;
            this.txtDescripcion.Location = new System.Drawing.Point(221, 115);
            this.txtDescripcion.MaxLength = 200;
            this.txtDescripcion.Multiline = true;
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(647, 63);
            this.txtDescripcion.TabIndex = 35;
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.ForeColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(221, 48);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(343, 3);
            this.panel4.TabIndex = 34;
            // 
            // txtNombreServicio
            // 
            this.txtNombreServicio.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNombreServicio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))));
            this.txtNombreServicio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNombreServicio.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreServicio.ForeColor = System.Drawing.Color.White;
            this.txtNombreServicio.Location = new System.Drawing.Point(221, 29);
            this.txtNombreServicio.MaxLength = 20;
            this.txtNombreServicio.Name = "txtNombreServicio";
            this.txtNombreServicio.Size = new System.Drawing.Size(343, 19);
            this.txtNombreServicio.TabIndex = 33;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(81, 115);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 20);
            this.label7.TabIndex = 30;
            this.label7.Text = "Descripción";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(644, 48);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 20);
            this.label9.TabIndex = 28;
            this.label9.Text = "Registro Activo";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(81, 65);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 20);
            this.label11.TabIndex = 26;
            this.label11.Text = "Costo Servicio";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(81, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(130, 20);
            this.label12.TabIndex = 25;
            this.label12.Text = "Nombre Servicio";
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(221, 84);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(343, 3);
            this.panel1.TabIndex = 43;
            // 
            // txtCostoServicio
            // 
            this.txtCostoServicio.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCostoServicio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))));
            this.txtCostoServicio.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCostoServicio.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCostoServicio.ForeColor = System.Drawing.Color.White;
            this.txtCostoServicio.Location = new System.Drawing.Point(221, 65);
            this.txtCostoServicio.Name = "txtCostoServicio";
            this.txtCostoServicio.Size = new System.Drawing.Size(343, 19);
            this.txtCostoServicio.TabIndex = 42;
            this.txtCostoServicio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCostoServicio_KeyPress);
            // 
            // chbDgEstado
            // 
            this.chbDgEstado.DataPropertyName = "estado";
            this.chbDgEstado.HeaderText = "Estado Registro";
            this.chbDgEstado.MinimumWidth = 6;
            this.chbDgEstado.Name = "chbDgEstado";
            this.chbDgEstado.ReadOnly = true;
            this.chbDgEstado.Width = 99;
            // 
            // btnEditar
            // 
            this.btnEditar.HeaderText = "Editar";
            this.btnEditar.MinimumWidth = 6;
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.ReadOnly = true;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseColumnTextForButtonValue = true;
            this.btnEditar.Width = 48;
            // 
            // VistaMantenedorServiciosExtras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))));
            this.ClientSize = new System.Drawing.Size(1044, 506);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtCostoServicio);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.dgvServicioExtra);
            this.Controls.Add(this.chbRegistro);
            this.Controls.Add(this.txtDescripcion);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.txtNombreServicio);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Name = "VistaMantenedorServiciosExtras";
            this.Text = "VistaMantenedorServiciosExtras";
            this.Load += new System.EventHandler(this.VistaMantenedorServiciosExtras_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvServicioExtra)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.DataGridView dgvServicioExtra;
        private System.Windows.Forms.CheckBox chbRegistro;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtNombreServicio;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtCostoServicio;
        private System.Windows.Forms.DataGridViewCheckBoxColumn chbDgEstado;
        private System.Windows.Forms.DataGridViewButtonColumn btnEditar;
    }
}