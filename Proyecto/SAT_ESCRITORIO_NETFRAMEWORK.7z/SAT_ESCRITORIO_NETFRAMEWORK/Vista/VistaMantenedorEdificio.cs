﻿using Modelo;
using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    public partial class VistaMantenedorEdificio : Form
    {
        public VistaMantenedorEdificio()
        {
            InitializeComponent();
            
        }

        public void LlenarCboRegion()
        {
            NegocioRegion negocioRegion = new NegocioRegion();
            List<ModeloRegion> datosRegion = negocioRegion.LeerRegion();
            datosRegion.Insert(0, new ModeloRegion(0, "Seleccione Región"));
            cboRegion.ValueMember = "id_region";
            cboRegion.DisplayMember = "nombre_region";
            cboRegion.DataSource = datosRegion;
        }

        public void LlenarCboComuna(int idRegion)
        {
            NegocioComuna negocioComuna = new NegocioComuna();
            ModeloRegion region = new ModeloRegion();
            region.id_region = idRegion;
            List<ModeloComuna> datosComuna = negocioComuna.LeerComuna(region);

            datosComuna.Insert(0, new ModeloComuna(0, "Seleccione Comuna"));
            cboComuna.DataSource = datosComuna;
            cboComuna.ValueMember = "id_comuna";
            cboComuna.DisplayMember = "nombre_comuna";
        }

        private void cboRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboRegion.SelectedIndex !=0)
            {
                int idRegion = Convert.ToInt32(cboRegion.SelectedValue);
                if (idRegion != 0)
                {
                    LlenarCboComuna(idRegion);
                }
                else
                {

                }
            }
            else
            {
                cboComuna.DataSource = null;
            }
            
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if(!String.IsNullOrEmpty(txtNombreEdificio.Text.Trim()))
            {
                if (cboRegion.SelectedIndex !=0)
                {
                    if (cboComuna.SelectedIndex !=0)
                    {
                        if (!String.IsNullOrEmpty(txtDireccion.Text.Trim()))
                        {
                            if (!String.IsNullOrEmpty(txtCantidadDePisos.Text.Trim()))
                            {
                                ModeloEdificio modeloEdificio = new ModeloEdificio();
                                NegocioEdificio negocioEdificio = new NegocioEdificio();
                                modeloEdificio.nombre_edificio = txtNombreEdificio.Text;
                                modeloEdificio.region = cboRegion.SelectedValue.ToString();
                                modeloEdificio.comuna = cboComuna.SelectedValue.ToString();
                                modeloEdificio.direccion = txtDireccion.Text;
                                modeloEdificio.cantidad_pisos = Convert.ToInt32(txtCantidadDePisos.Text);
                                modeloEdificio.registro_activo = Convert.ToInt32(chbRegistro.Checked);

                                bool respuesta = negocioEdificio.InsertarEdificio(modeloEdificio);
                                if (respuesta == true)
                                {
                                    MessageBox.Show("Registros Ingresados Correctamente");
                                    txtNombreEdificio.Clear();
                                    cboRegion.SelectedIndex = 0;
                                    cboComuna.DataSource = null; ;
                                    txtDireccion.Clear();
                                    txtCantidadDePisos.Clear();
                                    chbRegistro.Checked = false;
                                    CargarDgvEdificio();
                                }

                                
                            }
                            else
                            {
                                MessageBox.Show("Ingrese Cantidad De Pisos");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Ingrese Dirección");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Seleccione Comuna");
                    }
                }
                else
                {
                    MessageBox.Show("Seleccione Región");
                }
            }
            else
            {
                MessageBox.Show("Ingrese Nombre De Edificio");
            }
           
        }

        private void VistaMantenedorEdificio_Load(object sender, EventArgs e)
        {
            CargarDgvEdificio();
            LlenarCboRegion();
        }

        private void CargarDgvEdificio()
        {
            NegocioEdificio negocioEdificio = new NegocioEdificio();
            List<ModeloEdificio> listaEdificio = negocioEdificio.ListaEdificio();
            dgvEdificio.DataSource = listaEdificio;
            dgvEdificio.Columns["id_edificio"].HeaderText = "Id Edificio";
            dgvEdificio.Columns["id_edificio"].DisplayIndex = 0;
            dgvEdificio.Columns["nombre_edificio"].HeaderText = "Nombre Edificio";
            dgvEdificio.Columns["nombre_edificio"].DisplayIndex = 1;
            dgvEdificio.Columns["region"].HeaderText = "Región";
            dgvEdificio.Columns["region"].DisplayIndex = 2;
            dgvEdificio.Columns["comuna"].HeaderText = "Comuna";
            dgvEdificio.Columns["comuna"].DisplayIndex = 3;
            dgvEdificio.Columns["direccion"].HeaderText = "Dirección";
            dgvEdificio.Columns["direccion"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvEdificio.Columns["direccion"].DisplayIndex = 4;
            dgvEdificio.Columns["cantidad_pisos"].HeaderText = "Cantidad De Pisos";
            dgvEdificio.Columns["cantidad_pisos"].DisplayIndex = 5;
            //dgvEdificio.Columns["registro_activo"].HeaderText = "Estado Registro";
            //dgvEdificio.Columns["registro_activo"].DisplayIndex = 6;
            


        }

        private void dgvEdificio_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvEdificio.Columns[e.ColumnIndex].Name == "btnEditar")
            {
                int Id = Convert.ToInt32(dgvEdificio.CurrentRow.Cells["id_edificio"].Value.ToString());
                VistaEditarEdificio vistaEditarEdificio = new VistaEditarEdificio(Id);
                vistaEditarEdificio.ShowDialog();
                CargarDgvEdificio();
            }
        }

        private void txtCantidadDePisos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
