﻿namespace Vista
{
    partial class VistaMantenedorDepartamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlContenedor = new System.Windows.Forms.Panel();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtCantidadHabitaciones = new System.Windows.Forms.TextBox();
            this.cboEdificio = new System.Windows.Forms.ComboBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.dgvDepartamento = new System.Windows.Forms.DataGridView();
            this.chbRegistro = new System.Windows.Forms.CheckBox();
            this.cboNivelPiso = new System.Windows.Forms.ComboBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtNumDepartamento = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtCantidadDeBaños = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.chbDgEstado = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.btnEditar = new System.Windows.Forms.DataGridViewButtonColumn();
            this.pnlContenedor.SuspendLayout();
            this.pnlPrincipal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepartamento)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlContenedor
            // 
            this.pnlContenedor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))));
            this.pnlContenedor.Controls.Add(this.pnlPrincipal);
            this.pnlContenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContenedor.Location = new System.Drawing.Point(0, 0);
            this.pnlContenedor.Name = "pnlContenedor";
            this.pnlContenedor.Size = new System.Drawing.Size(1062, 553);
            this.pnlContenedor.TabIndex = 1;
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))));
            this.pnlPrincipal.Controls.Add(this.panel1);
            this.pnlPrincipal.Controls.Add(this.txtCantidadHabitaciones);
            this.pnlPrincipal.Controls.Add(this.cboEdificio);
            this.pnlPrincipal.Controls.Add(this.btnGuardar);
            this.pnlPrincipal.Controls.Add(this.dgvDepartamento);
            this.pnlPrincipal.Controls.Add(this.chbRegistro);
            this.pnlPrincipal.Controls.Add(this.cboNivelPiso);
            this.pnlPrincipal.Controls.Add(this.panel6);
            this.pnlPrincipal.Controls.Add(this.txtNumDepartamento);
            this.pnlPrincipal.Controls.Add(this.panel5);
            this.pnlPrincipal.Controls.Add(this.txtCantidadDeBaños);
            this.pnlPrincipal.Controls.Add(this.label7);
            this.pnlPrincipal.Controls.Add(this.label8);
            this.pnlPrincipal.Controls.Add(this.label9);
            this.pnlPrincipal.Controls.Add(this.label10);
            this.pnlPrincipal.Controls.Add(this.label11);
            this.pnlPrincipal.Controls.Add(this.label12);
            this.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrincipal.Location = new System.Drawing.Point(0, 0);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Size = new System.Drawing.Size(1062, 553);
            this.pnlPrincipal.TabIndex = 18;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(252, 205);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(42, 3);
            this.panel1.TabIndex = 27;
            // 
            // txtCantidadHabitaciones
            // 
            this.txtCantidadHabitaciones.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCantidadHabitaciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))));
            this.txtCantidadHabitaciones.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCantidadHabitaciones.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCantidadHabitaciones.ForeColor = System.Drawing.Color.White;
            this.txtCantidadHabitaciones.Location = new System.Drawing.Point(252, 186);
            this.txtCantidadHabitaciones.Name = "txtCantidadHabitaciones";
            this.txtCantidadHabitaciones.Size = new System.Drawing.Size(42, 19);
            this.txtCantidadHabitaciones.TabIndex = 26;
            this.txtCantidadHabitaciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCantidadHabitaciones_KeyPress);
            // 
            // cboEdificio
            // 
            this.cboEdificio.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cboEdificio.FormattingEnabled = true;
            this.cboEdificio.Location = new System.Drawing.Point(252, 57);
            this.cboEdificio.Name = "cboEdificio";
            this.cboEdificio.Size = new System.Drawing.Size(343, 24);
            this.cboEdificio.TabIndex = 25;
            this.cboEdificio.SelectedIndexChanged += new System.EventHandler(this.cboEdificio_SelectedIndexChanged);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnGuardar.Location = new System.Drawing.Point(422, 226);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(109, 32);
            this.btnGuardar.TabIndex = 24;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // dgvDepartamento
            // 
            this.dgvDepartamento.AllowUserToAddRows = false;
            this.dgvDepartamento.AllowUserToDeleteRows = false;
            this.dgvDepartamento.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dgvDepartamento.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvDepartamento.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvDepartamento.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvDepartamento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDepartamento.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chbDgEstado,
            this.btnEditar});
            this.dgvDepartamento.Location = new System.Drawing.Point(23, 273);
            this.dgvDepartamento.MultiSelect = false;
            this.dgvDepartamento.Name = "dgvDepartamento";
            this.dgvDepartamento.ReadOnly = true;
            this.dgvDepartamento.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgvDepartamento.RowTemplate.Height = 24;
            this.dgvDepartamento.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDepartamento.Size = new System.Drawing.Size(1011, 245);
            this.dgvDepartamento.TabIndex = 23;
            this.dgvDepartamento.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDepartamento_CellClick);
            // 
            // chbRegistro
            // 
            this.chbRegistro.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chbRegistro.AutoSize = true;
            this.chbRegistro.Location = new System.Drawing.Point(760, 105);
            this.chbRegistro.Name = "chbRegistro";
            this.chbRegistro.Size = new System.Drawing.Size(18, 17);
            this.chbRegistro.TabIndex = 22;
            this.chbRegistro.UseVisualStyleBackColor = true;
            // 
            // cboNivelPiso
            // 
            this.cboNivelPiso.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cboNivelPiso.FormattingEnabled = true;
            this.cboNivelPiso.Location = new System.Drawing.Point(252, 95);
            this.cboNivelPiso.Name = "cboNivelPiso";
            this.cboNivelPiso.Size = new System.Drawing.Size(343, 24);
            this.cboNivelPiso.TabIndex = 21;
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.ForeColor = System.Drawing.Color.White;
            this.panel6.Location = new System.Drawing.Point(252, 158);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(343, 3);
            this.panel6.TabIndex = 19;
            // 
            // txtNumDepartamento
            // 
            this.txtNumDepartamento.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNumDepartamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))));
            this.txtNumDepartamento.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNumDepartamento.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumDepartamento.ForeColor = System.Drawing.Color.White;
            this.txtNumDepartamento.Location = new System.Drawing.Point(252, 138);
            this.txtNumDepartamento.Name = "txtNumDepartamento";
            this.txtNumDepartamento.Size = new System.Drawing.Size(343, 19);
            this.txtNumDepartamento.TabIndex = 18;
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.ForeColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(760, 81);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(42, 3);
            this.panel5.TabIndex = 15;
            // 
            // txtCantidadDeBaños
            // 
            this.txtCantidadDeBaños.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCantidadDeBaños.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))));
            this.txtCantidadDeBaños.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCantidadDeBaños.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCantidadDeBaños.ForeColor = System.Drawing.Color.White;
            this.txtCantidadDeBaños.Location = new System.Drawing.Point(760, 62);
            this.txtCantidadDeBaños.Name = "txtCantidadDeBaños";
            this.txtCantidadDeBaños.Size = new System.Drawing.Size(42, 19);
            this.txtCantidadDeBaños.TabIndex = 14;
            this.txtCantidadDeBaños.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCantidadDeBaños_KeyPress);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(87, 176);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 40);
            this.label7.TabIndex = 5;
            this.label7.Text = "Cantidad de \r\nHabitaciones";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(614, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(151, 20);
            this.label8.TabIndex = 4;
            this.label8.Text = "Cantidad de baños";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(614, 102);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 20);
            this.label9.TabIndex = 3;
            this.label9.Text = "Registro Activo";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(87, 137);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(138, 20);
            this.label10.TabIndex = 2;
            this.label10.Text = "N° Departamento";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(87, 98);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "Nivel Piso";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(87, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(124, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Nombre Edificio";
            // 
            // chbDgEstado
            // 
            this.chbDgEstado.DataPropertyName = "estado_registro";
            this.chbDgEstado.HeaderText = "Estado Registro";
            this.chbDgEstado.MinimumWidth = 6;
            this.chbDgEstado.Name = "chbDgEstado";
            this.chbDgEstado.ReadOnly = true;
            this.chbDgEstado.Width = 99;
            // 
            // btnEditar
            // 
            this.btnEditar.HeaderText = "Editar";
            this.btnEditar.MinimumWidth = 6;
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.ReadOnly = true;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseColumnTextForButtonValue = true;
            this.btnEditar.Width = 48;
            // 
            // VistaMantenedorDepartamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1062, 553);
            this.Controls.Add(this.pnlContenedor);
            this.Name = "VistaMantenedorDepartamento";
            this.Text = "Mantenedor Departamento";
            this.Load += new System.EventHandler(this.VistaMantenedorDepartamento_Load);
            this.pnlContenedor.ResumeLayout(false);
            this.pnlPrincipal.ResumeLayout(false);
            this.pnlPrincipal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDepartamento)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlContenedor;
        private System.Windows.Forms.Panel pnlPrincipal;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.DataGridView dgvDepartamento;
        private System.Windows.Forms.CheckBox chbRegistro;
        private System.Windows.Forms.ComboBox cboNivelPiso;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txtNumDepartamento;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtCantidadDeBaños;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cboEdificio;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtCantidadHabitaciones;
        private System.Windows.Forms.DataGridViewCheckBoxColumn chbDgEstado;
        private System.Windows.Forms.DataGridViewButtonColumn btnEditar;
    }
}