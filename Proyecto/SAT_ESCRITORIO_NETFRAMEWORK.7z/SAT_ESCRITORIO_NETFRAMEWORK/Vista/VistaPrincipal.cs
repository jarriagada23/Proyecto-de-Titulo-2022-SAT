﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using FontAwesome.Sharp;
using Modelo;

namespace Vista
{
    public partial class VistaPrincipal : Form
    {
        private IconButton currentBtn;
        private Panel leftBorderBtn;
        private Form formularioHijoActual;
        public VistaPrincipal()
        {
            InitializeComponent();
            leftBorderBtn = new Panel();
            leftBorderBtn.Size = new Size(7, 40);
            pnlMenuVertical.Controls.Add(leftBorderBtn);

            this.Text = String.Empty;
            this.ControlBox = false;
            this.DoubleBuffered = true;
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;
        }

        private void ActivateButton(object senderBtn, Color color)
        {
            if(senderBtn != null)
            {
                DisableButton();
                currentBtn = (IconButton)senderBtn;
                currentBtn.BackColor = Color.FromArgb(37, 36, 81);
                currentBtn.ForeColor = color;
                currentBtn.TextAlign = ContentAlignment.MiddleCenter;
                currentBtn.IconColor = color;
                currentBtn.TextImageRelation = TextImageRelation.TextBeforeImage;
                currentBtn.ImageAlign = ContentAlignment.MiddleRight;

                leftBorderBtn.BackColor = color;
                leftBorderBtn.Location =   new Point(0, currentBtn.Location.Y);
                leftBorderBtn.Visible = true;
                leftBorderBtn.BringToFront();

                iconoFormularioHijoActual.IconChar = currentBtn.IconChar;
                iconoFormularioHijoActual.IconColor = color;
            }
        }

        private void DisableButton()
        {
            if(currentBtn != null)
            {
                currentBtn.BackColor = Color.FromArgb(0, 122, 204);
                currentBtn.ForeColor = Color.White;
                currentBtn.TextAlign = ContentAlignment.MiddleLeft;
                currentBtn.IconColor = Color.White;
                currentBtn.TextImageRelation = TextImageRelation.ImageBeforeText;
                currentBtn.ImageAlign = ContentAlignment.MiddleLeft;
            }
        }
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        public extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);
        //private void imgSlide_Click(object sender, EventArgs e)
        //{
        //    if(pnlMenuVertical.Width == 250)
        //    {
        //        pnlMenuVertical.Width = 70;
        //    }
        //    else
        //    {
        //        pnlMenuVertical.Width = 250;
        //    }
        //}
        private void AbrirFormularioHijo(Form childFrom)
        {
            if(formularioHijoActual != null)
            {
                formularioHijoActual.Close();
            }
            formularioHijoActual = childFrom;
            childFrom.TopLevel = false;
            childFrom.FormBorderStyle = FormBorderStyle.None;
            childFrom.Dock = DockStyle.Fill;
            pnlContenedor.Controls.Add(childFrom);
            pnlContenedor.Tag = childFrom;
            childFrom.BringToFront();
            childFrom.Show();
            lblTituloFormularioHijo.Text = childFrom.Text;

        }


        private void iconRestaurar_Click(object sender, EventArgs e)
        {
            

        }


        private void pnlBarraTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void btnMenuEdificio_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, Color.Violet);
            AbrirFormularioHijo(new VistaMantenedorEdificio());
        }

        private void btnMenuDepartamento_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, Color.Violet);
            AbrirFormularioHijo(new VistaMantenedorDepartamento());
        }

        private void btnMenuCliente_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, Color.Violet);
            AbrirFormularioHijo(new VistaMantenedorUsuario());
        }

        private void btnMenuDisponibilidad_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, Color.Violet);
        }

        private void btnMenuMantencion_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, Color.Violet);
        }

        private void btnMenuInventario_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, Color.Violet);
        }

        private void btnMenuCheckIn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, Color.Violet);
        }

        private void btnMenuCheckOut_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, Color.Violet);
        }

        private void btnMenuServiciosExtras_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, Color.Violet);
            AbrirFormularioHijo(new VistaMantenedorServicioExtra());
        }

        private void btnMenuTransporte_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, Color.Violet);
        }

        private void btnMenuReportes_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, Color.Violet);
        }

        private void Reset()
        {
            DisableButton();
            leftBorderBtn.Visible = false;
            iconoFormularioHijoActual.IconChar = IconChar.Home;
            iconoFormularioHijoActual.IconColor = Color.White;
            lblTituloFormularioHijo.Text = "Inicio";
        }

        private void imgLogoInicio_Click(object sender, EventArgs e)
        {
            formularioHijoActual.Close();
            Reset();
        }

        private void bntCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMaximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            btnRestaurar.Visible = true;
            btnMaximizar.Visible = false;
        }

        private void btnRestaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            btnRestaurar.Visible = false;
            btnMaximizar.Visible = true;
        }

        private void btnMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Esta seguro que desea salir?", "Advertencia", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                this.Close();
        }

        private void VistaPrincipal_Load(object sender, EventArgs e)
        {
            if(ModeloUsuarioCache.id_rol == 2)
            {
                btnMenuCliente.Enabled = false;
                btnMenuEdificio.Enabled = false;
                btnMenuDepartamento.Enabled = false;
                btnMenuDisponibilidad.Enabled = false;
                btnMenuInventario.Enabled = false;
                btnMenuMantencion.Enabled = false;
                btnMenuServiciosExtras.Enabled = false;
                btnMenuTransporte.Enabled = false; ;
                btnMenuReportes.Enabled = false;
            }
        }
    }
}
