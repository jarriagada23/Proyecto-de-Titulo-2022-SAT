﻿namespace Vista
{
    partial class VistaPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlMenuVertical = new System.Windows.Forms.Panel();
            this.btnSalir = new FontAwesome.Sharp.IconButton();
            this.btnMenuReportes = new FontAwesome.Sharp.IconButton();
            this.btnMenuTransporte = new FontAwesome.Sharp.IconButton();
            this.btnMenuServiciosExtras = new FontAwesome.Sharp.IconButton();
            this.btnMenuCheckOut = new FontAwesome.Sharp.IconButton();
            this.btnMenuCheckIn = new FontAwesome.Sharp.IconButton();
            this.btnMenuInventario = new FontAwesome.Sharp.IconButton();
            this.btnMenuMantencion = new FontAwesome.Sharp.IconButton();
            this.btnMenuDisponibilidad = new FontAwesome.Sharp.IconButton();
            this.btnMenuCliente = new FontAwesome.Sharp.IconButton();
            this.btnMenuDepartamento = new FontAwesome.Sharp.IconButton();
            this.btnMenuEdificio = new FontAwesome.Sharp.IconButton();
            this.pnlLogo = new System.Windows.Forms.Panel();
            this.imgLogoInicio = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlBarraTitulo = new System.Windows.Forms.Panel();
            this.btnMinimizar = new FontAwesome.Sharp.IconButton();
            this.bntCerrar = new FontAwesome.Sharp.IconButton();
            this.btnMaximizar = new FontAwesome.Sharp.IconButton();
            this.lblTituloFormularioHijo = new System.Windows.Forms.Label();
            this.btnRestaurar = new FontAwesome.Sharp.IconButton();
            this.iconoFormularioHijoActual = new FontAwesome.Sharp.IconPictureBox();
            this.pnlContenedor = new System.Windows.Forms.Panel();
            this.imgLogoContenedor = new System.Windows.Forms.PictureBox();
            this.pnlSombra = new System.Windows.Forms.Panel();
            this.pnlMenuVertical.SuspendLayout();
            this.pnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoInicio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlBarraTitulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconoFormularioHijoActual)).BeginInit();
            this.pnlContenedor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoContenedor)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlMenuVertical
            // 
            this.pnlMenuVertical.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.pnlMenuVertical.Controls.Add(this.btnSalir);
            this.pnlMenuVertical.Controls.Add(this.btnMenuReportes);
            this.pnlMenuVertical.Controls.Add(this.btnMenuTransporte);
            this.pnlMenuVertical.Controls.Add(this.btnMenuServiciosExtras);
            this.pnlMenuVertical.Controls.Add(this.btnMenuCheckOut);
            this.pnlMenuVertical.Controls.Add(this.btnMenuCheckIn);
            this.pnlMenuVertical.Controls.Add(this.btnMenuInventario);
            this.pnlMenuVertical.Controls.Add(this.btnMenuMantencion);
            this.pnlMenuVertical.Controls.Add(this.btnMenuDisponibilidad);
            this.pnlMenuVertical.Controls.Add(this.btnMenuCliente);
            this.pnlMenuVertical.Controls.Add(this.btnMenuDepartamento);
            this.pnlMenuVertical.Controls.Add(this.btnMenuEdificio);
            this.pnlMenuVertical.Controls.Add(this.pnlLogo);
            this.pnlMenuVertical.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenuVertical.Location = new System.Drawing.Point(0, 0);
            this.pnlMenuVertical.Name = "pnlMenuVertical";
            this.pnlMenuVertical.Size = new System.Drawing.Size(220, 650);
            this.pnlMenuVertical.TabIndex = 0;
            // 
            // btnSalir
            // 
            this.btnSalir.FlatAppearance.BorderSize = 0;
            this.btnSalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalir.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.ForeColor = System.Drawing.Color.White;
            this.btnSalir.IconChar = FontAwesome.Sharp.IconChar.Outdent;
            this.btnSalir.IconColor = System.Drawing.Color.White;
            this.btnSalir.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnSalir.IconSize = 35;
            this.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalir.Location = new System.Drawing.Point(0, 610);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnSalir.Size = new System.Drawing.Size(220, 40);
            this.btnSalir.TabIndex = 12;
            this.btnSalir.Text = "Salir";
            this.btnSalir.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSalir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnMenuReportes
            // 
            this.btnMenuReportes.FlatAppearance.BorderSize = 0;
            this.btnMenuReportes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuReportes.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuReportes.ForeColor = System.Drawing.Color.White;
            this.btnMenuReportes.IconChar = FontAwesome.Sharp.IconChar.ChartColumn;
            this.btnMenuReportes.IconColor = System.Drawing.Color.White;
            this.btnMenuReportes.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMenuReportes.IconSize = 35;
            this.btnMenuReportes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuReportes.Location = new System.Drawing.Point(0, 506);
            this.btnMenuReportes.Name = "btnMenuReportes";
            this.btnMenuReportes.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnMenuReportes.Size = new System.Drawing.Size(220, 40);
            this.btnMenuReportes.TabIndex = 11;
            this.btnMenuReportes.Text = "Reportes";
            this.btnMenuReportes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuReportes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMenuReportes.UseVisualStyleBackColor = true;
            this.btnMenuReportes.Click += new System.EventHandler(this.btnMenuReportes_Click);
            // 
            // btnMenuTransporte
            // 
            this.btnMenuTransporte.FlatAppearance.BorderSize = 0;
            this.btnMenuTransporte.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuTransporte.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuTransporte.ForeColor = System.Drawing.Color.White;
            this.btnMenuTransporte.IconChar = FontAwesome.Sharp.IconChar.CarRear;
            this.btnMenuTransporte.IconColor = System.Drawing.Color.White;
            this.btnMenuTransporte.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMenuTransporte.IconSize = 35;
            this.btnMenuTransporte.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuTransporte.Location = new System.Drawing.Point(0, 470);
            this.btnMenuTransporte.Name = "btnMenuTransporte";
            this.btnMenuTransporte.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnMenuTransporte.Size = new System.Drawing.Size(220, 40);
            this.btnMenuTransporte.TabIndex = 10;
            this.btnMenuTransporte.Text = "Transporte";
            this.btnMenuTransporte.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuTransporte.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMenuTransporte.UseVisualStyleBackColor = true;
            this.btnMenuTransporte.Click += new System.EventHandler(this.btnMenuTransporte_Click);
            // 
            // btnMenuServiciosExtras
            // 
            this.btnMenuServiciosExtras.FlatAppearance.BorderSize = 0;
            this.btnMenuServiciosExtras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuServiciosExtras.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuServiciosExtras.ForeColor = System.Drawing.Color.White;
            this.btnMenuServiciosExtras.IconChar = FontAwesome.Sharp.IconChar.BellConcierge;
            this.btnMenuServiciosExtras.IconColor = System.Drawing.Color.White;
            this.btnMenuServiciosExtras.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMenuServiciosExtras.IconSize = 35;
            this.btnMenuServiciosExtras.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuServiciosExtras.Location = new System.Drawing.Point(0, 431);
            this.btnMenuServiciosExtras.Name = "btnMenuServiciosExtras";
            this.btnMenuServiciosExtras.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnMenuServiciosExtras.Size = new System.Drawing.Size(220, 40);
            this.btnMenuServiciosExtras.TabIndex = 9;
            this.btnMenuServiciosExtras.Text = "Servicios Extras";
            this.btnMenuServiciosExtras.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuServiciosExtras.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMenuServiciosExtras.UseVisualStyleBackColor = true;
            this.btnMenuServiciosExtras.Click += new System.EventHandler(this.btnMenuServiciosExtras_Click);
            // 
            // btnMenuCheckOut
            // 
            this.btnMenuCheckOut.FlatAppearance.BorderSize = 0;
            this.btnMenuCheckOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuCheckOut.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuCheckOut.ForeColor = System.Drawing.Color.White;
            this.btnMenuCheckOut.IconChar = FontAwesome.Sharp.IconChar.CheckDouble;
            this.btnMenuCheckOut.IconColor = System.Drawing.Color.White;
            this.btnMenuCheckOut.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMenuCheckOut.IconSize = 35;
            this.btnMenuCheckOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuCheckOut.Location = new System.Drawing.Point(0, 392);
            this.btnMenuCheckOut.Name = "btnMenuCheckOut";
            this.btnMenuCheckOut.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnMenuCheckOut.Size = new System.Drawing.Size(220, 40);
            this.btnMenuCheckOut.TabIndex = 8;
            this.btnMenuCheckOut.Text = "Check Out";
            this.btnMenuCheckOut.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuCheckOut.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMenuCheckOut.UseVisualStyleBackColor = true;
            this.btnMenuCheckOut.Click += new System.EventHandler(this.btnMenuCheckOut_Click);
            // 
            // btnMenuCheckIn
            // 
            this.btnMenuCheckIn.FlatAppearance.BorderSize = 0;
            this.btnMenuCheckIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuCheckIn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuCheckIn.ForeColor = System.Drawing.Color.White;
            this.btnMenuCheckIn.IconChar = FontAwesome.Sharp.IconChar.Check;
            this.btnMenuCheckIn.IconColor = System.Drawing.Color.White;
            this.btnMenuCheckIn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMenuCheckIn.IconSize = 35;
            this.btnMenuCheckIn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuCheckIn.Location = new System.Drawing.Point(0, 356);
            this.btnMenuCheckIn.Name = "btnMenuCheckIn";
            this.btnMenuCheckIn.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnMenuCheckIn.Size = new System.Drawing.Size(220, 40);
            this.btnMenuCheckIn.TabIndex = 7;
            this.btnMenuCheckIn.Text = "Check In";
            this.btnMenuCheckIn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuCheckIn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMenuCheckIn.UseVisualStyleBackColor = true;
            this.btnMenuCheckIn.Click += new System.EventHandler(this.btnMenuCheckIn_Click);
            // 
            // btnMenuInventario
            // 
            this.btnMenuInventario.FlatAppearance.BorderSize = 0;
            this.btnMenuInventario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuInventario.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuInventario.ForeColor = System.Drawing.Color.White;
            this.btnMenuInventario.IconChar = FontAwesome.Sharp.IconChar.ListOl;
            this.btnMenuInventario.IconColor = System.Drawing.Color.White;
            this.btnMenuInventario.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMenuInventario.IconSize = 35;
            this.btnMenuInventario.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuInventario.Location = new System.Drawing.Point(0, 317);
            this.btnMenuInventario.Name = "btnMenuInventario";
            this.btnMenuInventario.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnMenuInventario.Size = new System.Drawing.Size(220, 40);
            this.btnMenuInventario.TabIndex = 6;
            this.btnMenuInventario.Text = "Inventario";
            this.btnMenuInventario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuInventario.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMenuInventario.UseVisualStyleBackColor = true;
            this.btnMenuInventario.Click += new System.EventHandler(this.btnMenuInventario_Click);
            // 
            // btnMenuMantencion
            // 
            this.btnMenuMantencion.FlatAppearance.BorderSize = 0;
            this.btnMenuMantencion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuMantencion.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuMantencion.ForeColor = System.Drawing.Color.White;
            this.btnMenuMantencion.IconChar = FontAwesome.Sharp.IconChar.Wrench;
            this.btnMenuMantencion.IconColor = System.Drawing.Color.White;
            this.btnMenuMantencion.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMenuMantencion.IconSize = 35;
            this.btnMenuMantencion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuMantencion.Location = new System.Drawing.Point(0, 281);
            this.btnMenuMantencion.Name = "btnMenuMantencion";
            this.btnMenuMantencion.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnMenuMantencion.Size = new System.Drawing.Size(220, 40);
            this.btnMenuMantencion.TabIndex = 5;
            this.btnMenuMantencion.Text = "Mantención";
            this.btnMenuMantencion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuMantencion.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMenuMantencion.UseVisualStyleBackColor = true;
            this.btnMenuMantencion.Click += new System.EventHandler(this.btnMenuMantencion_Click);
            // 
            // btnMenuDisponibilidad
            // 
            this.btnMenuDisponibilidad.FlatAppearance.BorderSize = 0;
            this.btnMenuDisponibilidad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuDisponibilidad.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuDisponibilidad.ForeColor = System.Drawing.Color.White;
            this.btnMenuDisponibilidad.IconChar = FontAwesome.Sharp.IconChar.ClockFour;
            this.btnMenuDisponibilidad.IconColor = System.Drawing.Color.White;
            this.btnMenuDisponibilidad.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMenuDisponibilidad.IconSize = 35;
            this.btnMenuDisponibilidad.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuDisponibilidad.Location = new System.Drawing.Point(0, 242);
            this.btnMenuDisponibilidad.Name = "btnMenuDisponibilidad";
            this.btnMenuDisponibilidad.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnMenuDisponibilidad.Size = new System.Drawing.Size(220, 40);
            this.btnMenuDisponibilidad.TabIndex = 4;
            this.btnMenuDisponibilidad.Text = "Disponibilidad";
            this.btnMenuDisponibilidad.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuDisponibilidad.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMenuDisponibilidad.UseVisualStyleBackColor = true;
            this.btnMenuDisponibilidad.Click += new System.EventHandler(this.btnMenuDisponibilidad_Click);
            // 
            // btnMenuCliente
            // 
            this.btnMenuCliente.FlatAppearance.BorderSize = 0;
            this.btnMenuCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuCliente.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuCliente.ForeColor = System.Drawing.Color.White;
            this.btnMenuCliente.IconChar = FontAwesome.Sharp.IconChar.PersonCircleCheck;
            this.btnMenuCliente.IconColor = System.Drawing.Color.White;
            this.btnMenuCliente.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMenuCliente.IconSize = 35;
            this.btnMenuCliente.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuCliente.Location = new System.Drawing.Point(0, 206);
            this.btnMenuCliente.Name = "btnMenuCliente";
            this.btnMenuCliente.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnMenuCliente.Size = new System.Drawing.Size(220, 40);
            this.btnMenuCliente.TabIndex = 3;
            this.btnMenuCliente.Text = "Cliente";
            this.btnMenuCliente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMenuCliente.UseVisualStyleBackColor = true;
            this.btnMenuCliente.Click += new System.EventHandler(this.btnMenuCliente_Click);
            // 
            // btnMenuDepartamento
            // 
            this.btnMenuDepartamento.FlatAppearance.BorderSize = 0;
            this.btnMenuDepartamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuDepartamento.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuDepartamento.ForeColor = System.Drawing.Color.White;
            this.btnMenuDepartamento.IconChar = FontAwesome.Sharp.IconChar.DoorOpen;
            this.btnMenuDepartamento.IconColor = System.Drawing.Color.White;
            this.btnMenuDepartamento.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMenuDepartamento.IconSize = 35;
            this.btnMenuDepartamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuDepartamento.Location = new System.Drawing.Point(0, 167);
            this.btnMenuDepartamento.Name = "btnMenuDepartamento";
            this.btnMenuDepartamento.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnMenuDepartamento.Size = new System.Drawing.Size(220, 40);
            this.btnMenuDepartamento.TabIndex = 2;
            this.btnMenuDepartamento.Text = "Departamento";
            this.btnMenuDepartamento.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuDepartamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMenuDepartamento.UseVisualStyleBackColor = true;
            this.btnMenuDepartamento.Click += new System.EventHandler(this.btnMenuDepartamento_Click);
            // 
            // btnMenuEdificio
            // 
            this.btnMenuEdificio.FlatAppearance.BorderSize = 0;
            this.btnMenuEdificio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenuEdificio.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenuEdificio.ForeColor = System.Drawing.Color.White;
            this.btnMenuEdificio.IconChar = FontAwesome.Sharp.IconChar.Hotel;
            this.btnMenuEdificio.IconColor = System.Drawing.Color.White;
            this.btnMenuEdificio.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMenuEdificio.IconSize = 35;
            this.btnMenuEdificio.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuEdificio.Location = new System.Drawing.Point(0, 128);
            this.btnMenuEdificio.Name = "btnMenuEdificio";
            this.btnMenuEdificio.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.btnMenuEdificio.Size = new System.Drawing.Size(220, 40);
            this.btnMenuEdificio.TabIndex = 1;
            this.btnMenuEdificio.Text = "Edificio";
            this.btnMenuEdificio.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMenuEdificio.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnMenuEdificio.UseVisualStyleBackColor = true;
            this.btnMenuEdificio.Click += new System.EventHandler(this.btnMenuEdificio_Click);
            // 
            // pnlLogo
            // 
            this.pnlLogo.Controls.Add(this.imgLogoInicio);
            this.pnlLogo.Controls.Add(this.pictureBox1);
            this.pnlLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogo.Location = new System.Drawing.Point(0, 0);
            this.pnlLogo.Name = "pnlLogo";
            this.pnlLogo.Size = new System.Drawing.Size(220, 100);
            this.pnlLogo.TabIndex = 0;
            // 
            // imgLogoInicio
            // 
            this.imgLogoInicio.Image = global::Vista.Properties.Resources.img_logo_SAT;
            this.imgLogoInicio.Location = new System.Drawing.Point(0, 0);
            this.imgLogoInicio.Name = "imgLogoInicio";
            this.imgLogoInicio.Size = new System.Drawing.Size(203, 100);
            this.imgLogoInicio.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgLogoInicio.TabIndex = 0;
            this.imgLogoInicio.TabStop = false;
            this.imgLogoInicio.Click += new System.EventHandler(this.imgLogoInicio_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(220, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pnlBarraTitulo
            // 
            this.pnlBarraTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.pnlBarraTitulo.Controls.Add(this.btnMinimizar);
            this.pnlBarraTitulo.Controls.Add(this.bntCerrar);
            this.pnlBarraTitulo.Controls.Add(this.btnMaximizar);
            this.pnlBarraTitulo.Controls.Add(this.lblTituloFormularioHijo);
            this.pnlBarraTitulo.Controls.Add(this.btnRestaurar);
            this.pnlBarraTitulo.Controls.Add(this.iconoFormularioHijoActual);
            this.pnlBarraTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlBarraTitulo.Location = new System.Drawing.Point(220, 0);
            this.pnlBarraTitulo.Name = "pnlBarraTitulo";
            this.pnlBarraTitulo.Size = new System.Drawing.Size(1080, 50);
            this.pnlBarraTitulo.TabIndex = 1;
            this.pnlBarraTitulo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlBarraTitulo_MouseDown);
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnMinimizar.FlatAppearance.BorderSize = 0;
            this.btnMinimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimizar.IconChar = FontAwesome.Sharp.IconChar.WindowMinimize;
            this.btnMinimizar.IconColor = System.Drawing.Color.White;
            this.btnMinimizar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMinimizar.IconSize = 23;
            this.btnMinimizar.Location = new System.Drawing.Point(989, 10);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(24, 24);
            this.btnMinimizar.TabIndex = 5;
            this.btnMinimizar.UseVisualStyleBackColor = false;
            this.btnMinimizar.Click += new System.EventHandler(this.btnMinimizar_Click);
            // 
            // bntCerrar
            // 
            this.bntCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bntCerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.bntCerrar.FlatAppearance.BorderSize = 0;
            this.bntCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bntCerrar.IconChar = FontAwesome.Sharp.IconChar.X;
            this.bntCerrar.IconColor = System.Drawing.Color.White;
            this.bntCerrar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.bntCerrar.IconSize = 23;
            this.bntCerrar.Location = new System.Drawing.Point(1049, 10);
            this.bntCerrar.Name = "bntCerrar";
            this.bntCerrar.Size = new System.Drawing.Size(24, 24);
            this.bntCerrar.TabIndex = 2;
            this.bntCerrar.UseVisualStyleBackColor = false;
            this.bntCerrar.Click += new System.EventHandler(this.bntCerrar_Click);
            // 
            // btnMaximizar
            // 
            this.btnMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnMaximizar.FlatAppearance.BorderSize = 0;
            this.btnMaximizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximizar.IconChar = FontAwesome.Sharp.IconChar.WindowMaximize;
            this.btnMaximizar.IconColor = System.Drawing.Color.White;
            this.btnMaximizar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnMaximizar.IconSize = 23;
            this.btnMaximizar.Location = new System.Drawing.Point(1019, 11);
            this.btnMaximizar.Name = "btnMaximizar";
            this.btnMaximizar.Size = new System.Drawing.Size(24, 24);
            this.btnMaximizar.TabIndex = 4;
            this.btnMaximizar.UseVisualStyleBackColor = false;
            this.btnMaximizar.Click += new System.EventHandler(this.btnMaximizar_Click);
            // 
            // lblTituloFormularioHijo
            // 
            this.lblTituloFormularioHijo.AutoSize = true;
            this.lblTituloFormularioHijo.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloFormularioHijo.ForeColor = System.Drawing.Color.White;
            this.lblTituloFormularioHijo.Location = new System.Drawing.Point(48, 14);
            this.lblTituloFormularioHijo.Name = "lblTituloFormularioHijo";
            this.lblTituloFormularioHijo.Size = new System.Drawing.Size(49, 20);
            this.lblTituloFormularioHijo.TabIndex = 4;
            this.lblTituloFormularioHijo.Text = "Inicio";
            // 
            // btnRestaurar
            // 
            this.btnRestaurar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRestaurar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnRestaurar.FlatAppearance.BorderSize = 0;
            this.btnRestaurar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRestaurar.IconChar = FontAwesome.Sharp.IconChar.WindowRestore;
            this.btnRestaurar.IconColor = System.Drawing.Color.White;
            this.btnRestaurar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnRestaurar.IconSize = 23;
            this.btnRestaurar.Location = new System.Drawing.Point(1019, 12);
            this.btnRestaurar.Name = "btnRestaurar";
            this.btnRestaurar.Size = new System.Drawing.Size(24, 24);
            this.btnRestaurar.TabIndex = 3;
            this.btnRestaurar.UseVisualStyleBackColor = false;
            this.btnRestaurar.Click += new System.EventHandler(this.btnRestaurar_Click);
            // 
            // iconoFormularioHijoActual
            // 
            this.iconoFormularioHijoActual.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.iconoFormularioHijoActual.IconChar = FontAwesome.Sharp.IconChar.Home;
            this.iconoFormularioHijoActual.IconColor = System.Drawing.Color.White;
            this.iconoFormularioHijoActual.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconoFormularioHijoActual.Location = new System.Drawing.Point(15, 8);
            this.iconoFormularioHijoActual.Name = "iconoFormularioHijoActual";
            this.iconoFormularioHijoActual.Size = new System.Drawing.Size(32, 32);
            this.iconoFormularioHijoActual.TabIndex = 3;
            this.iconoFormularioHijoActual.TabStop = false;
            // 
            // pnlContenedor
            // 
            this.pnlContenedor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(200)))));
            this.pnlContenedor.Controls.Add(this.imgLogoContenedor);
            this.pnlContenedor.Controls.Add(this.pnlSombra);
            this.pnlContenedor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContenedor.Location = new System.Drawing.Point(220, 50);
            this.pnlContenedor.Name = "pnlContenedor";
            this.pnlContenedor.Size = new System.Drawing.Size(1080, 600);
            this.pnlContenedor.TabIndex = 2;
            // 
            // imgLogoContenedor
            // 
            this.imgLogoContenedor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.imgLogoContenedor.Image = global::Vista.Properties.Resources.img_logo_SAT;
            this.imgLogoContenedor.Location = new System.Drawing.Point(481, 246);
            this.imgLogoContenedor.Name = "imgLogoContenedor";
            this.imgLogoContenedor.Size = new System.Drawing.Size(203, 100);
            this.imgLogoContenedor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgLogoContenedor.TabIndex = 1;
            this.imgLogoContenedor.TabStop = false;
            // 
            // pnlSombra
            // 
            this.pnlSombra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(141)))), ((int)(((byte)(200)))));
            this.pnlSombra.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSombra.Location = new System.Drawing.Point(0, 0);
            this.pnlSombra.Name = "pnlSombra";
            this.pnlSombra.Size = new System.Drawing.Size(1080, 9);
            this.pnlSombra.TabIndex = 0;
            // 
            // VistaPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 650);
            this.Controls.Add(this.pnlContenedor);
            this.Controls.Add(this.pnlBarraTitulo);
            this.Controls.Add(this.pnlMenuVertical);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "VistaPrincipal";
            this.Opacity = 0.9D;
            this.Text = "VistaPrincipal";
            this.Load += new System.EventHandler(this.VistaPrincipal_Load);
            this.pnlMenuVertical.ResumeLayout(false);
            this.pnlLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoInicio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlBarraTitulo.ResumeLayout(false);
            this.pnlBarraTitulo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconoFormularioHijoActual)).EndInit();
            this.pnlContenedor.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imgLogoContenedor)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMenuVertical;
        private System.Windows.Forms.Panel pnlLogo;
        private System.Windows.Forms.Panel pnlBarraTitulo;
        private System.Windows.Forms.Panel pnlContenedor;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox imgLogoInicio;
        private FontAwesome.Sharp.IconButton btnMenuReportes;
        private FontAwesome.Sharp.IconButton btnMenuTransporte;
        private FontAwesome.Sharp.IconButton btnMenuServiciosExtras;
        private FontAwesome.Sharp.IconButton btnMenuCheckOut;
        private FontAwesome.Sharp.IconButton btnMenuCheckIn;
        private FontAwesome.Sharp.IconButton btnMenuInventario;
        private FontAwesome.Sharp.IconButton btnMenuMantencion;
        private FontAwesome.Sharp.IconButton btnMenuDisponibilidad;
        private FontAwesome.Sharp.IconButton btnMenuCliente;
        private FontAwesome.Sharp.IconButton btnMenuDepartamento;
        private FontAwesome.Sharp.IconButton btnMenuEdificio;
        private FontAwesome.Sharp.IconPictureBox iconoFormularioHijoActual;
        private System.Windows.Forms.Label lblTituloFormularioHijo;
        private System.Windows.Forms.Panel pnlSombra;
        private System.Windows.Forms.PictureBox imgLogoContenedor;
        private FontAwesome.Sharp.IconButton bntCerrar;
        private FontAwesome.Sharp.IconButton btnMaximizar;
        private FontAwesome.Sharp.IconButton btnMinimizar;
        private FontAwesome.Sharp.IconButton btnRestaurar;
        private FontAwesome.Sharp.IconButton btnSalir;
    }
}