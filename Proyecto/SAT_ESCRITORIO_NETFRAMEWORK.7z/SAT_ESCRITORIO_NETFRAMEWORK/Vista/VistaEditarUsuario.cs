﻿using Modelo;
using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    public partial class VistaEditarUsuario : Form
    {
        int varIdUsuario = 0;
        public VistaEditarUsuario(int idUsuario)
        {
            InitializeComponent();
            buscarUsuario(idUsuario);
            varIdUsuario = idUsuario;
        }

        private void VistaEditarUsuario_Load(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtRut_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtDv_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar.ToString().ToUpper() != "K")
            {
                e.Handled = true;
            }
        }
        public static bool ValidaRut(string rut)
        {
            rut = rut.Replace(".", "").ToUpper();
            Regex expresion = new Regex("^([0-9]+-[0-9K])$");
            string dv = rut.Substring(rut.Length - 1, 1);
            if (!expresion.IsMatch(rut))
            {
                return false;
            }
            char[] charCorte = { '-' };
            string[] rutTemp = rut.Split(charCorte);
            if (dv != Digito(int.Parse(rutTemp[0])))
            {
                return false;
            }
            return true;
        }

        public static bool ValidaRut(string rut, string dv)
        {
            return ValidaRut(rut + "-" + dv);
        }

        public static string Digito(int rut)
        {
            int suma = 0;
            int multiplicador = 1;
            while (rut != 0)
            {
                multiplicador++;
                if (multiplicador == 8)
                    multiplicador = 2;
                suma += (rut % 10) * multiplicador;
                rut = rut / 10;
            }
            suma = 11 - (suma % 11);
            if (suma == 11)
            {
                return "0";
            }
            else if (suma == 10)
            {
                return "K";
            }
            else
            {
                return suma.ToString();
            }
        }

        public static bool ComprobarFormatoEmail(string email)
        {
            String sFormato;
            sFormato = "\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*";
            if (Regex.IsMatch(email, sFormato))
            {
                if (Regex.Replace(email, sFormato, String.Empty).Length == 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public void LlenarCboRegion()
        {
            List<ModeloRegion> datosRegion = DatosRegion();
            datosRegion.Insert(0, new ModeloRegion(0, "Seleccione Región"));
            cboRegion.ValueMember = "id_region";
            cboRegion.DisplayMember = "nombre_region";
            cboRegion.DataSource = datosRegion;
        }

        public void LlenarCboComuna(int idRegion)
        {
            List<ModeloComuna> datosComuna = DatosComuna(idRegion);
            datosComuna.Insert(0, new ModeloComuna(0, "Seleccione Comuna"));
            cboComuna.DataSource = datosComuna;
            cboComuna.ValueMember = "id_comuna";
            cboComuna.DisplayMember = "nombre_comuna";
        }

        public List<ModeloRegion> DatosRegion()
        {
            NegocioRegion negocioRegion = new NegocioRegion();
            List<ModeloRegion> datosRegion = negocioRegion.LeerRegion();
            return datosRegion;
        }
        public List<ModeloComuna> DatosComuna(int idRegion)
        {
            NegocioComuna negocioComuna = new NegocioComuna();
            ModeloRegion region = new ModeloRegion();
            region.id_region = idRegion;
            List<ModeloComuna> datosComuna = negocioComuna.LeerComuna(region);

            return datosComuna;

        }

        private void cboRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboRegion.SelectedIndex != 0)
            {
                int idRegion = Convert.ToInt32(cboRegion.SelectedValue);
                if (idRegion != 0)
                {
                    LlenarCboComuna(idRegion);
                }
                else
                {

                }
            }
            else
            {
                cboComuna.DataSource = null;
            }
        }

        private void buscarUsuario(int idUsuario)
        {
            NegocioUsuario negocioUsuario = new NegocioUsuario();
            ModeloUsuario modeloUsuario = new ModeloUsuario();
            modeloUsuario.id_usuario = idUsuario;
            ModeloUsuario datosUsuario = negocioUsuario.BuscarUsuario(modeloUsuario);
            LlenarCboRegion();
            List<ModeloRegion> datosRegion = DatosRegion();
            int idRegion = 0;
            foreach (var item in datosRegion)
            {
                if (item.nombre_region == datosUsuario.region)
                {
                    idRegion = item.id_region;
                }
            }
            LlenarCboComuna(idRegion);
            List<ModeloComuna> datosComuna = DatosComuna(idRegion);
            int idComuna = 0;
            foreach (var item in datosComuna)
            {
                if (item.nombre_comuna == datosUsuario.comuna)
                {
                    idComuna = item.id_comuna;
                }
            }
            txtRut.Text = datosUsuario.rut.ToString();
            txtDv.Text = datosUsuario.dv.ToString();
            txtNombre.Text = datosUsuario.nombre;
            txtApPaterno.Text = datosUsuario.ap_paterno;
            txtApMaterno.Text = datosUsuario.ap_materno;
            txtEmail.Text = datosUsuario.email;
            txtTelefono.Text = datosUsuario.telefono.ToString();
            cboRegion.SelectedValue = idRegion;
            cboComuna.SelectedValue = idComuna;
            txtDireccion.Text = datosUsuario.direccion;
            txtUsuario.Text = datosUsuario.usuario;
            txtContraseña.Text = datosUsuario.contraseña;
            chbRegistro.Checked = Convert.ToBoolean(datosUsuario.estado);
            dtpFechaNacimiento.Value = datosUsuario.fch_nacimiento;

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtRut.Text.Trim()))
            {
                if (!String.IsNullOrEmpty(txtDv.Text.Trim()))
                {
                    if (ValidaRut(txtRut.Text, txtDv.Text))
                    {
                        if (!String.IsNullOrEmpty(txtNombre.Text.Trim()))
                        {
                            if (!String.IsNullOrEmpty(txtApPaterno.Text.Trim()))
                            {
                                if (!String.IsNullOrEmpty(txtApMaterno.Text.Trim()))
                                {
                                    if (!String.IsNullOrEmpty(txtEmail.Text.Trim()))
                                    {
                                        if (ComprobarFormatoEmail(txtEmail.Text.Trim()))
                                        {
                                            if (!String.IsNullOrEmpty(txtDireccion.Text.Trim()))
                                            {
                                                if (Convert.ToDateTime(dtpFechaNacimiento.Text) < DateTime.Now.Date)
                                                {
                                                    if (!String.IsNullOrEmpty(txtTelefono.Text.Trim()))
                                                    {
                                                        if (cboRegion.SelectedIndex != 0)
                                                        {
                                                            if (cboComuna.SelectedIndex != 0)
                                                            {
                                                                if (!String.IsNullOrEmpty(txtUsuario.Text.Trim()))
                                                                {
                                                                    if (!String.IsNullOrEmpty(txtContraseña.Text.Trim()))
                                                                    {
                                                                        ModeloUsuario modeloUsuario = new ModeloUsuario();
                                                                        NegocioUsuario negocioUsuario = new NegocioUsuario();
                                                                        modeloUsuario.id_usuario = varIdUsuario;
                                                                        modeloUsuario.rut = Convert.ToInt32(txtRut.Text);
                                                                        modeloUsuario.dv = txtDv.Text;
                                                                        modeloUsuario.nombre = txtNombre.Text;
                                                                        modeloUsuario.ap_paterno = txtApPaterno.Text;
                                                                        modeloUsuario.ap_materno = txtApMaterno.Text;
                                                                        modeloUsuario.email = txtEmail.Text;
                                                                        modeloUsuario.direccion = txtDireccion.Text;
                                                                        modeloUsuario.usuario = txtUsuario.Text;
                                                                        modeloUsuario.contraseña = txtContraseña.Text;
                                                                        modeloUsuario.fch_nacimiento = Convert.ToDateTime(dtpFechaNacimiento.Text);
                                                                        modeloUsuario.telefono = Convert.ToInt32(txtTelefono.Text);
                                                                        modeloUsuario.region = cboRegion.SelectedValue.ToString();
                                                                        modeloUsuario.comuna = cboComuna.SelectedValue.ToString();
                                                                        modeloUsuario.estado = Convert.ToInt32(chbRegistro.Checked);
                                                                        modeloUsuario.id_rol = 3;

                                                                        bool respuesta = negocioUsuario.EditarUsuario(modeloUsuario);
                                                                        if (respuesta == true)
                                                                        {
                                                                            MessageBox.Show("Registros Modificados Correctamente");
                                                                            txtRut.Clear();
                                                                            txtDv.Clear();
                                                                            txtNombre.Clear();
                                                                            txtApPaterno.Clear();
                                                                            txtApMaterno.Clear();
                                                                            txtEmail.Clear();
                                                                            txtDireccion.Clear();
                                                                            txtUsuario.Clear();
                                                                            txtContraseña.Clear();
                                                                            dtpFechaNacimiento.Value = DateTime.Now.Date;
                                                                            txtTelefono.Clear();
                                                                            cboRegion.SelectedIndex = 0;
                                                                            cboComuna.DataSource = null;
                                                                            chbRegistro.Checked = false;
                                                                            this.Close();
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        MessageBox.Show("Ingrese Contraseña");
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    MessageBox.Show("Ingrese Usuario");
                                                                }
                                                            }
                                                            else
                                                            {
                                                                MessageBox.Show("Seleccione Comuna");
                                                            }
                                                        }
                                                        else
                                                        {
                                                            MessageBox.Show("Seleccione Región");
                                                        }
                                                    }
                                                    else
                                                    {
                                                        MessageBox.Show("Ingrese Telefono");
                                                    }
                                                }
                                                else
                                                {
                                                    MessageBox.Show("Seleccione Una Fecha Menor A La Actual");
                                                }
                                            }
                                            else
                                            {
                                                MessageBox.Show("Ingrese Dirección");
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Formato de Email Incorrecto");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Ingrese Email");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Ingrese Apellido Materno");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Ingrese Apellido Paterno");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Ingrese Nombre");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Rut Invalido");
                    }
                }
                else
                {
                    MessageBox.Show("Ingrese Digito Verificador");
                }
            }
            else
            {
                MessageBox.Show("Ingrese Rut");
            }
        }
    }
}
