﻿using Modelo;
using Negocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    public partial class VistaEditarEdificio : Form
    {
        int varIdEdificio = 0;
        public VistaEditarEdificio(int idEdificio)
        {
            InitializeComponent();
            varIdEdificio = idEdificio;
            buscarEdificio(idEdificio);
        }

        public void LlenarCboRegion()
        {
            List<ModeloRegion> datosRegion = DatosRegion();
            datosRegion.Insert(0, new ModeloRegion(0, "Seleccione Región"));
            cboRegion.ValueMember = "id_region";
            cboRegion.DisplayMember = "nombre_region";
            cboRegion.DataSource = datosRegion;
        }

        public void LlenarCboComuna(int idRegion)
        {
            List<ModeloComuna> datosComuna = DatosComuna(idRegion);
            datosComuna.Insert(0, new ModeloComuna(0, "Seleccione Comuna"));
            cboComuna.DataSource = datosComuna;
            cboComuna.ValueMember = "id_comuna";
            cboComuna.DisplayMember = "nombre_comuna";
        }

        private void cboRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboRegion.SelectedIndex != 0)
            {
                int idRegion = Convert.ToInt32(cboRegion.SelectedValue);
                if (idRegion != 0)
                {
                    LlenarCboComuna(idRegion);
                }
                else
                {

                }
            }
            else
            {
                cboComuna.DataSource = null;
            }
        }
        public List<ModeloRegion> DatosRegion ()
        {
            NegocioRegion negocioRegion = new NegocioRegion();
            List<ModeloRegion> datosRegion = negocioRegion.LeerRegion();
            return datosRegion;
        }
        public List<ModeloComuna> DatosComuna(int idRegion)
        {
            NegocioComuna negocioComuna = new NegocioComuna();
            ModeloRegion region = new ModeloRegion();
            region.id_region = idRegion;
            List<ModeloComuna> datosComuna = negocioComuna.LeerComuna(region);

            return datosComuna;

        }
        private void buscarEdificio(int idEdificio)
        {
            NegocioEdificio negocioEdificio = new NegocioEdificio();
            ModeloEdificio modeloEdificio = new ModeloEdificio();
            modeloEdificio.id_edificio = idEdificio;
            ModeloEdificio datosEdificio = negocioEdificio.BuscarEdificio(modeloEdificio);
            LlenarCboRegion();
            List<ModeloRegion> datosRegion = DatosRegion();
            int idRegion = 0;
            foreach(var item in datosRegion)
            {
                if(item.nombre_region == datosEdificio.region)
                {
                    idRegion = item.id_region;
                }
            }
            LlenarCboComuna(idRegion);
            List<ModeloComuna> datosComuna = DatosComuna(idRegion);
            int idComuna = 0;
            foreach(var item in datosComuna)
            {
                if(item.nombre_comuna == datosEdificio.comuna)
                {
                    idComuna = item.id_comuna;
                }    
            }


            txtNombreEdificio.Text = datosEdificio.nombre_edificio;
            cboRegion.SelectedValue = idRegion;
            cboComuna.SelectedValue = idComuna;
            txtDireccion.Text = datosEdificio.direccion;
            txtCantidadDePisos.Text = datosEdificio.cantidad_pisos.ToString();
            chbRegistro.Checked = Convert.ToBoolean(datosEdificio.registro_activo);

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnModifciar_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txtNombreEdificio.Text.Trim()))
            {
                if (cboRegion.SelectedIndex != 0)
                {
                    if (cboComuna.SelectedIndex != 0)
                    {
                        if (!String.IsNullOrEmpty(txtDireccion.Text.Trim()))
                        {
                            if (!String.IsNullOrEmpty(txtCantidadDePisos.Text.Trim()))
                            {
                                ModeloEdificio modeloEdificio = new ModeloEdificio();
                                NegocioEdificio negocioEdificio = new NegocioEdificio();
                                modeloEdificio.id_edificio = varIdEdificio;
                                modeloEdificio.nombre_edificio = txtNombreEdificio.Text;
                                modeloEdificio.region = cboRegion.SelectedValue.ToString();
                                modeloEdificio.comuna = cboComuna.SelectedValue.ToString();
                                modeloEdificio.direccion = txtDireccion.Text;
                                modeloEdificio.cantidad_pisos = Convert.ToInt32(txtCantidadDePisos.Text);
                                modeloEdificio.registro_activo = Convert.ToInt32(chbRegistro.Checked);

                                bool respuesta = negocioEdificio.EditarEdificio(modeloEdificio);
                                if (respuesta == true)
                                {
                                    MessageBox.Show("Registros Modificados Correctamente");
                                    //txtNombreEdificio.Clear();
                                    //cboRegion.SelectedIndex = 0;
                                    //cboComuna.DataSource = null; ;
                                    //txtDireccion.Clear();
                                    //txtCantidadDePisos.Clear();
                                    //chbRegistro.Checked = false;
                                    this.Close();
                                }


                            }
                            else
                            {
                                MessageBox.Show("Ingrese Cantidad De Pisos");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Ingrese Dirección");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Seleccione Comuna");
                    }
                }
                else
                {
                    MessageBox.Show("Seleccione Región");
                }
            }
            else
            {
                MessageBox.Show("Ingrese Nombre De Edificio");
            }
        }
    }
}
