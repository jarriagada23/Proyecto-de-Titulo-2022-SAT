﻿namespace Vista
{
    partial class VistaEditarDepartamento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtCantidadHabitaciones = new System.Windows.Forms.TextBox();
            this.cboEdificio = new System.Windows.Forms.ComboBox();
            this.btnModificar = new System.Windows.Forms.Button();
            this.chbRegistro = new System.Windows.Forms.CheckBox();
            this.cboNivelPiso = new System.Windows.Forms.ComboBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtNumDepartamento = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtCantidadDeBaños = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(197, 166);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(42, 3);
            this.panel1.TabIndex = 43;
            // 
            // txtCantidadHabitaciones
            // 
            this.txtCantidadHabitaciones.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCantidadHabitaciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtCantidadHabitaciones.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCantidadHabitaciones.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCantidadHabitaciones.ForeColor = System.Drawing.Color.White;
            this.txtCantidadHabitaciones.Location = new System.Drawing.Point(197, 147);
            this.txtCantidadHabitaciones.Name = "txtCantidadHabitaciones";
            this.txtCantidadHabitaciones.Size = new System.Drawing.Size(42, 19);
            this.txtCantidadHabitaciones.TabIndex = 42;
            // 
            // cboEdificio
            // 
            this.cboEdificio.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cboEdificio.FormattingEnabled = true;
            this.cboEdificio.Location = new System.Drawing.Point(197, 18);
            this.cboEdificio.Name = "cboEdificio";
            this.cboEdificio.Size = new System.Drawing.Size(343, 24);
            this.cboEdificio.TabIndex = 41;
            this.cboEdificio.SelectedIndexChanged += new System.EventHandler(this.cboEdificio_SelectedIndexChanged);
            // 
            // btnModificar
            // 
            this.btnModificar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificar.Location = new System.Drawing.Point(585, 94);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(109, 32);
            this.btnModificar.TabIndex = 40;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // chbRegistro
            // 
            this.chbRegistro.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chbRegistro.AutoSize = true;
            this.chbRegistro.Location = new System.Drawing.Point(716, 62);
            this.chbRegistro.Name = "chbRegistro";
            this.chbRegistro.Size = new System.Drawing.Size(18, 17);
            this.chbRegistro.TabIndex = 39;
            this.chbRegistro.UseVisualStyleBackColor = true;
            // 
            // cboNivelPiso
            // 
            this.cboNivelPiso.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cboNivelPiso.FormattingEnabled = true;
            this.cboNivelPiso.Location = new System.Drawing.Point(197, 56);
            this.cboNivelPiso.Name = "cboNivelPiso";
            this.cboNivelPiso.Size = new System.Drawing.Size(343, 24);
            this.cboNivelPiso.TabIndex = 38;
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.ForeColor = System.Drawing.Color.White;
            this.panel6.Location = new System.Drawing.Point(197, 119);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(343, 3);
            this.panel6.TabIndex = 37;
            // 
            // txtNumDepartamento
            // 
            this.txtNumDepartamento.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNumDepartamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtNumDepartamento.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNumDepartamento.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumDepartamento.ForeColor = System.Drawing.Color.White;
            this.txtNumDepartamento.Location = new System.Drawing.Point(197, 99);
            this.txtNumDepartamento.Name = "txtNumDepartamento";
            this.txtNumDepartamento.Size = new System.Drawing.Size(343, 19);
            this.txtNumDepartamento.TabIndex = 36;
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.ForeColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(716, 45);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(42, 3);
            this.panel5.TabIndex = 35;
            // 
            // txtCantidadDeBaños
            // 
            this.txtCantidadDeBaños.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCantidadDeBaños.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtCantidadDeBaños.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCantidadDeBaños.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCantidadDeBaños.ForeColor = System.Drawing.Color.White;
            this.txtCantidadDeBaños.Location = new System.Drawing.Point(716, 26);
            this.txtCantidadDeBaños.Name = "txtCantidadDeBaños";
            this.txtCantidadDeBaños.Size = new System.Drawing.Size(42, 19);
            this.txtCantidadDeBaños.TabIndex = 34;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(32, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 36);
            this.label7.TabIndex = 33;
            this.label7.Text = "Cantidad de \r\nHabitaciones";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(559, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(150, 18);
            this.label8.TabIndex = 32;
            this.label8.Text = "Cantidad de baños";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(559, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(117, 18);
            this.label9.TabIndex = 31;
            this.label9.Text = "Registro Activo";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(32, 98);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(136, 18);
            this.label10.TabIndex = 30;
            this.label10.Text = "N° Departamento";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(32, 59);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 18);
            this.label11.TabIndex = 29;
            this.label11.Text = "Nivel Piso";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(32, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(126, 18);
            this.label12.TabIndex = 28;
            this.label12.Text = "Nombre Edificio";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.Location = new System.Drawing.Point(585, 137);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(109, 32);
            this.btnCancelar.TabIndex = 44;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // VistaEditarDepartamento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(778, 237);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtCantidadHabitaciones);
            this.Controls.Add(this.cboEdificio);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.chbRegistro);
            this.Controls.Add(this.cboNivelPiso);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.txtNumDepartamento);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.txtCantidadDeBaños);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "VistaEditarDepartamento";
            this.Text = "VistaEditarDepartamento";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtCantidadHabitaciones;
        private System.Windows.Forms.ComboBox cboEdificio;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.CheckBox chbRegistro;
        private System.Windows.Forms.ComboBox cboNivelPiso;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txtNumDepartamento;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtCantidadDeBaños;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnCancelar;
    }
}