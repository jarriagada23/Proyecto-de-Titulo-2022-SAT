﻿using Modelo;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DatosComuna:Conexion
    {
        public List<ModeloComuna> LeerComuna(ModeloRegion region)
        {
            List<ModeloComuna> listaComuna = new List<ModeloComuna>();
            using (var conexion = GetConexion())
            {
                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Comuna";
                    comando.Parameters.AddWithValue("@id_region", region.id_region);
                    SqlDataReader reader = comando.ExecuteReader();

                    while (reader.Read())
                    {
                        listaComuna.Add(new ModeloComuna(Convert.ToInt32(reader[0]), Convert.ToString(reader[1])));
                    }
                    return listaComuna;
                }
            }
        }
    }
}
