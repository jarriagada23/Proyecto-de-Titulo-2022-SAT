﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modelo;

namespace Datos
{
    public class DatosUsuario : Conexion
    {
        public int Login(ModeloUsuario usuario)
        {
            using (var conexion = GetConexion())
            {
                int id = 0;
                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_VerficiarUsuario";
                    comando.Parameters.AddWithValue("@usuario", usuario.usuario);
                    comando.Parameters.AddWithValue("@contraseña", usuario.contraseña);
                    SqlDataReader reader = comando.ExecuteReader();
                    
                    if(reader.HasRows)
                    {
                        while(reader.Read())
                        {
                            ModeloUsuarioCache.id_usuario = reader.GetInt32(0);
                            ModeloUsuarioCache.nombre = reader.GetString(1);
                            ModeloUsuarioCache.ap_paterno = reader.GetString(2);
                            ModeloUsuarioCache.ap_materno = reader.GetString(3);
                            ModeloUsuarioCache.email = reader.GetString(4);
                            ModeloUsuarioCache.usuario = reader.GetString(5);
                            ModeloUsuarioCache.contraseña = reader.GetString(6);
                            ModeloUsuarioCache.id_rol = reader.GetInt32(7);

                        }
                        return 1;
                    }
                    return 0;


                }
            }
        }

        public bool InsertarUsuario(ModeloUsuario usuario)
        {
            bool respuesta;
            using (var conexion = GetConexion())
            {
                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Usuario";
                    comando.Parameters.AddWithValue("@accion", 'C');
                    comando.Parameters.AddWithValue("@rut", usuario.rut);
                    comando.Parameters.AddWithValue("@dv", usuario.dv);
                    comando.Parameters.AddWithValue("@nombre", usuario.nombre);
                    comando.Parameters.AddWithValue("@ap_paterno", usuario.ap_paterno);
                    comando.Parameters.AddWithValue("@ap_materno", usuario.ap_materno);
                    comando.Parameters.AddWithValue("@email", usuario.email);
                    comando.Parameters.AddWithValue("@telefono", usuario.telefono);
                    comando.Parameters.AddWithValue("@id_region", usuario.region);
                    comando.Parameters.AddWithValue("@id_comuna", usuario.comuna);
                    comando.Parameters.AddWithValue("@direccion", usuario.direccion);
                    comando.Parameters.AddWithValue("@fch_nacimiento", usuario.fch_nacimiento);
                    comando.Parameters.AddWithValue("@estado", usuario.estado);
                    comando.Parameters.AddWithValue("@usuario", usuario.usuario);
                    comando.Parameters.AddWithValue("@contraseña", usuario.contraseña);
                    comando.Parameters.AddWithValue("@id_rol", usuario.id_rol);
                    comando.ExecuteNonQuery();

                    return respuesta = true;
                }
            }
        }

        public List<ModeloUsuario> ListaUsuario()
        {

            List<ModeloUsuario> listaUsuario = new List<ModeloUsuario>();
            using (var conexion = GetConexion())
            {
                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Usuario";
                    comando.Parameters.AddWithValue("@accion", 'R');
                    SqlDataReader read = comando.ExecuteReader();
                    while (read.Read())
                    {
                        listaUsuario.Add(new ModeloUsuario(Convert.ToInt32(read[0]), Convert.ToInt32(read[1]), Convert.ToString(read[2]), Convert.ToString(read[3]), Convert.ToString(read[4]), Convert.ToString(read[5]),
                                                           Convert.ToString(read[6]), Convert.ToInt32(read[7]), Convert.ToString(read[8]), Convert.ToString(read[9]), Convert.ToString(read[10]), Convert.ToDateTime(read[11]),
                                                           Convert.ToInt32(read[12]), Convert.ToString(read[13]), Convert.ToString(read[14])));
                    }
                    return listaUsuario;
                }
            }
        }

        public ModeloUsuario BuscarUsuario(ModeloUsuario modeloUsuario)
        {
            ModeloUsuario datosUsuario = new ModeloUsuario();
            using (var conexion = GetConexion())
            {
                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Usuario";
                    comando.Parameters.AddWithValue("@accion", 'B');
                    comando.Parameters.AddWithValue("@id_usuario", modeloUsuario.id_usuario);
                    SqlDataReader read = comando.ExecuteReader();
                    while (read.Read())
                    {
                        datosUsuario.id_usuario = Convert.ToInt32(read[0]);
                        datosUsuario.rut = Convert.ToInt32(read[1]);
                        datosUsuario.dv = Convert.ToString(read[2]);
                        datosUsuario.nombre = Convert.ToString(read[3]);
                        datosUsuario.ap_paterno = Convert.ToString(read[4]);
                        datosUsuario.ap_materno = Convert.ToString(read[5]);
                        datosUsuario.email = Convert.ToString(read[6]);
                        datosUsuario.telefono = Convert.ToInt32(read[7]);
                        datosUsuario.region = Convert.ToString(read[8]);
                        datosUsuario.comuna = Convert.ToString(read[9]);
                        datosUsuario.direccion = Convert.ToString(read[10]);
                        datosUsuario.fch_nacimiento = Convert.ToDateTime(read[11]);
                        datosUsuario.estado = Convert.ToInt32(read[12]);
                        datosUsuario.usuario = Convert.ToString(read[13]);
                        datosUsuario.contraseña = Convert.ToString(read[14]);
                    }

                    return datosUsuario;
                }
            }
        }
        public bool EditarUsuario(ModeloUsuario usuario)
        {
            bool respuesta;
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Usuario";
                    comando.Parameters.AddWithValue("@accion", 'U');
                    comando.Parameters.AddWithValue("@id_usuario", usuario.id_usuario);
                    comando.Parameters.AddWithValue("@rut", usuario.rut);
                    comando.Parameters.AddWithValue("@dv", usuario.dv);
                    comando.Parameters.AddWithValue("@nombre", usuario.nombre);
                    comando.Parameters.AddWithValue("@ap_paterno", usuario.ap_paterno);
                    comando.Parameters.AddWithValue("@ap_materno", usuario.ap_materno);
                    comando.Parameters.AddWithValue("@email", usuario.email);
                    comando.Parameters.AddWithValue("@telefono", usuario.telefono);
                    comando.Parameters.AddWithValue("@id_region", usuario.region);
                    comando.Parameters.AddWithValue("@id_comuna", usuario.comuna);
                    comando.Parameters.AddWithValue("@direccion", usuario.direccion);
                    comando.Parameters.AddWithValue("@fch_nacimiento", usuario.fch_nacimiento);
                    comando.Parameters.AddWithValue("@estado", usuario.estado);
                    comando.Parameters.AddWithValue("@usuario", usuario.usuario);
                    comando.Parameters.AddWithValue("@contraseña", usuario.contraseña);
                    comando.Parameters.AddWithValue("@id_rol", usuario.id_rol);
                    comando.ExecuteNonQuery();

                    return respuesta = true;
                }
            }
        }
    }
}
