﻿using Modelo;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DatosRegion : Conexion
    {
        public List<ModeloRegion> LeerRegion ()
        {
            List<ModeloRegion> listaRegion = new List<ModeloRegion>();
            using (var conexion = GetConexion())
            {
               
                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Region";
                    SqlDataReader reader = comando.ExecuteReader();
                    
                    while(reader.Read())
                    {
                        listaRegion.Add(new ModeloRegion(Convert.ToInt32(reader[0]), Convert.ToString(reader[1])));
                    }
                    return listaRegion;
                }
            }
        }
    }
}
