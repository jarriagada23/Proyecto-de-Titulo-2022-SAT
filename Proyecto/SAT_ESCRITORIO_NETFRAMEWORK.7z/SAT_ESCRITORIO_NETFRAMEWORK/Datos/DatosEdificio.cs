﻿
using Modelo;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DatosEdificio:Conexion
    {
        public bool InsertarEdificio(ModeloEdificio edificio)
        {
            bool respuesta;
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Edificio";
                    comando.Parameters.AddWithValue("@accion", 'C');
                    comando.Parameters.AddWithValue("@nombre_edificio", edificio.nombre_edificio);
                    comando.Parameters.AddWithValue("@id_region", edificio.region);
                    comando.Parameters.AddWithValue("@id_comuna", edificio.comuna);
                    comando.Parameters.AddWithValue("@direccion", edificio.direccion);
                    comando.Parameters.AddWithValue("@cantidad_piso", edificio.cantidad_pisos);
                    comando.Parameters.AddWithValue("@estado", edificio.registro_activo);
                    comando.ExecuteNonQuery();

                    return respuesta = true;
                }
            }
        }

        public List<ModeloEdificio> ListaEdificio()
        {
            List<ModeloEdificio> listaEdificio = new List<ModeloEdificio>();
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Edificio";
                    comando.Parameters.AddWithValue("@accion", 'R');
                    SqlDataReader read = comando.ExecuteReader();
                    while(read.Read())
                    {
                        listaEdificio.Add(new ModeloEdificio(Convert.ToInt32(read[0]), Convert.ToString(read[1]), Convert.ToString(read[2]), Convert.ToString(read[3]), Convert.ToString(read[4]), Convert.ToInt32(read[5]), Convert.ToInt32(read[6])));
                    }

                    return listaEdificio;
                }
            }
        }

        public ModeloEdificio BuscarEdificio(ModeloEdificio modeloEdificio)
        {
            ModeloEdificio datosEdificio = new ModeloEdificio();
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Edificio";
                    comando.Parameters.AddWithValue("@accion", 'B');
                    comando.Parameters.AddWithValue("@id_edificio", modeloEdificio.id_edificio);
                    SqlDataReader read = comando.ExecuteReader();
                    while (read.Read())
                    {
                        datosEdificio.id_edificio = Convert.ToInt32(read[0]);
                        datosEdificio.nombre_edificio = Convert.ToString(read[1]);
                        datosEdificio.region = Convert.ToString(read[2]);
                        datosEdificio.comuna = Convert.ToString(read[3]);
                        datosEdificio.direccion = Convert.ToString(read[4]);
                        datosEdificio.cantidad_pisos = Convert.ToInt32(read[5]);
                        datosEdificio.registro_activo = Convert.ToInt32(read[6]);
                    }

                    return datosEdificio;
                }
            }
        }

        public bool EditarEdificio(ModeloEdificio edificio)
        {
            bool respuesta;
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Edificio";
                    comando.Parameters.AddWithValue("@accion", 'U');
                    comando.Parameters.AddWithValue("@id_edificio", edificio.id_edificio);
                    comando.Parameters.AddWithValue("@nombre_edificio", edificio.nombre_edificio);
                    comando.Parameters.AddWithValue("@id_region", edificio.region);
                    comando.Parameters.AddWithValue("@id_comuna", edificio.comuna);
                    comando.Parameters.AddWithValue("@direccion", edificio.direccion);
                    comando.Parameters.AddWithValue("@cantidad_piso", edificio.cantidad_pisos);
                    comando.Parameters.AddWithValue("@estado", edificio.registro_activo);
                    comando.ExecuteNonQuery();

                    return respuesta = true;
                }
            }
        }

        public List<ModeloEdificio> ListaEdificioCbo()
        {
            List<ModeloEdificio> listaEdificio = new List<ModeloEdificio>();
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Edificio";
                    comando.Parameters.AddWithValue("@accion", 'L');
                    SqlDataReader read = comando.ExecuteReader();
                    while (read.Read())
                    {
                        listaEdificio.Add(new ModeloEdificio(Convert.ToInt32(read[0]), Convert.ToString(read[1])));
                    }

                    return listaEdificio;
                }
            }
        }
    }
}
