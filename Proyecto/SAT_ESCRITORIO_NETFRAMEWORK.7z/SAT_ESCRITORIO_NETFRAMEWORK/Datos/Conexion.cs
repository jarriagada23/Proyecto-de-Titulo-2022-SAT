﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class Conexion
    {
        private readonly string cadenaConexion;
        public Conexion()
        {
            cadenaConexion = "Data Source=LAPTOP-TEQTI8VS\\SQLEXPRESS;Initial Catalog=SAT;Persist Security Info=True;User ID=SAT;Password=SAT1234";
        }
        protected SqlConnection GetConexion()
        {
            return new SqlConnection(cadenaConexion);
        }
    }
}
