﻿using Modelo;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DatosServiciosExtra:Conexion
    {
        public bool InsertarServicioExtra(ModeloServicioExtra servicioExtra)
        {
            bool respuesta;
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_ServicioExtra";
                    comando.Parameters.AddWithValue("@accion", 'C');
                    comando.Parameters.AddWithValue("@nombreServicio", servicioExtra.nombreServicio);
                    comando.Parameters.AddWithValue("@costoServicio", servicioExtra.costoServicio);
                    comando.Parameters.AddWithValue("@descripcion", servicioExtra.descripcion);
                    comando.Parameters.AddWithValue("@estado", servicioExtra.estado);
                    comando.ExecuteNonQuery();

                    return respuesta = true;
                }
            }
        }

        public List<ModeloServicioExtra> ListaServicioExtra()
        {
            List<ModeloServicioExtra> listaServicioExtra = new List<ModeloServicioExtra>();
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_ServicioExtra";
                    comando.Parameters.AddWithValue("@accion", 'R');
                    SqlDataReader read = comando.ExecuteReader();
                    while (read.Read())
                    {
                        listaServicioExtra.Add(new ModeloServicioExtra(Convert.ToInt32(read[0]), Convert.ToString(read[1]), Convert.ToInt32(read[2]), Convert.ToString(read[3]), Convert.ToInt32(read[4])));
                    }

                    return listaServicioExtra;
                }
            }
        }

        public ModeloServicioExtra BuscarServicio(ModeloServicioExtra servicioExtra)
        {
            ModeloServicioExtra datosServicio = new ModeloServicioExtra();
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_ServicioExtra";
                    comando.Parameters.AddWithValue("@accion", 'B');
                    comando.Parameters.AddWithValue("@idServicio", servicioExtra.idServicio);
                    SqlDataReader read = comando.ExecuteReader();
                    while (read.Read())
                    {
                        datosServicio.idServicio = Convert.ToInt32(read[0]);
                        datosServicio.nombreServicio = Convert.ToString(read[1]);
                        datosServicio.costoServicio = Convert.ToInt32(read[2]);
                        datosServicio.descripcion = Convert.ToString(read[3]);
                        datosServicio.estado = Convert.ToInt32(read[4]);
                    }

                    return datosServicio;
                }
            }
        }

        public bool EditarServicio(ModeloServicioExtra servicioExtra)
        {
            bool respuesta;
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_ServicioExtra";
                    comando.Parameters.AddWithValue("@accion", 'U');
                    comando.Parameters.AddWithValue("@idServicio", servicioExtra.idServicio);
                    comando.Parameters.AddWithValue("@nombreServicio", servicioExtra.nombreServicio);
                    comando.Parameters.AddWithValue("@costoServicio", servicioExtra.costoServicio);
                    comando.Parameters.AddWithValue("@descripcion", servicioExtra.descripcion);
                    comando.Parameters.AddWithValue("@estado", servicioExtra.estado);
                    comando.ExecuteNonQuery();

                    return respuesta = true;
                }
            }
        }
    }
}
