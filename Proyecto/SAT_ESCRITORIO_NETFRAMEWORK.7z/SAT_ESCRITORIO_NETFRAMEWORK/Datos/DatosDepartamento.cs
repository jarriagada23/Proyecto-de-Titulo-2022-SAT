﻿using Modelo;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class DatosDepartamento:Conexion
    {
        public bool InsertarDepartamento(ModeloDepartamento departamento)
        {
            bool respuesta;
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Departamento";
                    comando.Parameters.AddWithValue("@accion", 'C');
                    comando.Parameters.AddWithValue("@nivel_piso", departamento.nivel_piso);
                    comando.Parameters.AddWithValue("@num_departamento", departamento.num_departamento);
                    comando.Parameters.AddWithValue("@cantidad_habitaciones", departamento.cantidad_habitaciones);
                    comando.Parameters.AddWithValue("@cantidad_baños", departamento.cantidad_baños);
                    comando.Parameters.AddWithValue("@id_edificio", departamento.edificio);
                    comando.Parameters.AddWithValue("@estado", departamento.estado_registro);
                    comando.ExecuteNonQuery();

                    return respuesta = true;
                }
            }
        }

        public List<ModeloDepartamento> ListaDepartamento()
        {
             
            List<ModeloDepartamento> listadepartamento = new List<ModeloDepartamento>();
            using (var conexion = GetConexion())
            {
                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Departamento";
                    comando.Parameters.AddWithValue("@accion", 'R');
                    SqlDataReader read = comando.ExecuteReader();
                    while (read.Read())
                    {
                        listadepartamento.Add(new ModeloDepartamento(Convert.ToInt32(read[0]), Convert.ToString(read[6]), Convert.ToInt32(read[1]), Convert.ToString(read[2]), Convert.ToInt32(read[3]), Convert.ToInt32(read[4]), Convert.ToInt32(read[5])));
                    }

                    return listadepartamento;
                }
            }
        }

        public ModeloDepartamento BuscarDepartamento(ModeloDepartamento modeloDepartamento)
        {
            ModeloDepartamento datosDepartamento = new ModeloDepartamento();
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Departamento";
                    comando.Parameters.AddWithValue("@accion", 'B');
                    comando.Parameters.AddWithValue("@id_departamento", modeloDepartamento.id_departamento);
                    SqlDataReader read = comando.ExecuteReader();
                    while (read.Read())
                    {
                        datosDepartamento.id_departamento = Convert.ToInt32(read[0]);
                        datosDepartamento.nivel_piso = Convert.ToInt32(read[1]);
                        datosDepartamento.num_departamento = Convert.ToString(read[2]);
                        datosDepartamento.cantidad_habitaciones = Convert.ToInt32(read[3]);
                        datosDepartamento.cantidad_baños = Convert.ToInt32(read[4]);
                        datosDepartamento.estado_registro = Convert.ToInt32(read[5]);
                        datosDepartamento.edificio = Convert.ToString(read[6]);
                    }

                    return datosDepartamento;
                }
            }
        }

        public bool EditarDepartamento(ModeloDepartamento departamento)
        {
            bool respuesta;
            using (var conexion = GetConexion())
            {

                conexion.Open();
                using (var comando = new SqlCommand())
                {
                    comando.Connection = conexion;
                    comando.CommandType = CommandType.StoredProcedure;
                    comando.CommandText = "SP_Departamento";
                    comando.Parameters.AddWithValue("@accion", 'U');
                    comando.Parameters.AddWithValue("@id_departamento", departamento.id_departamento);
                    comando.Parameters.AddWithValue("@nivel_piso", departamento.nivel_piso);
                    comando.Parameters.AddWithValue("@num_departamento", departamento.num_departamento);
                    comando.Parameters.AddWithValue("@cantidad_habitaciones", departamento.cantidad_habitaciones);
                    comando.Parameters.AddWithValue("@cantidad_baños", departamento.cantidad_baños);
                    comando.Parameters.AddWithValue("@id_edificio", departamento.edificio);
                    comando.Parameters.AddWithValue("@estado", departamento.estado_registro);
                    comando.ExecuteNonQuery();

                    return respuesta = true;
                }
            }
        }

    }
}
