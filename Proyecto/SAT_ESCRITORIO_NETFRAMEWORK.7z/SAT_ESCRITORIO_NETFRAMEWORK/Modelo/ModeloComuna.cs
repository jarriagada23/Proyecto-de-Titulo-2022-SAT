﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class ModeloComuna
    {
        public int id_comuna { get; set; }
        public string nombre_comuna { get; set; }

        public ModeloComuna(int id_comuna, string nombre_comuna)
        {
            this.id_comuna = id_comuna;
            this.nombre_comuna = nombre_comuna;
        }
        public ModeloComuna()
        {
            
        }


    }
}
