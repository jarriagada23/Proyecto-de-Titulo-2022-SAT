﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class ModeloRegion
    {
        public int id_region { get; set; }
        public string nombre_region { get; set; }

        public ModeloRegion(int id_region, string nombre_region)
        {
            this.id_region = id_region;
            this.nombre_region = nombre_region;
        }

        public ModeloRegion()
        {
        }
    }
}
