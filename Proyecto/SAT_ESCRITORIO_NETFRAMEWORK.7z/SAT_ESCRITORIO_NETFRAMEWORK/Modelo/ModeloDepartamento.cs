﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class ModeloDepartamento
    {
        public int id_departamento { get; set; }
        public string edificio { get; set; }
        public int nivel_piso { get; set; }
        public string num_departamento { get; set; }
        public int cantidad_habitaciones { get; set; }
        public int cantidad_baños { get; set; }
        public int estado_registro { get; set; }
       

        public ModeloDepartamento(int id_departamento, string edificio,int nivel_piso, string num_departamento, int cantidad_habitaciones, int cantidad_baños, int estado_registro)
        {
            this.id_departamento = id_departamento;
            this.nivel_piso = nivel_piso;
            this.num_departamento = num_departamento;
            this.cantidad_habitaciones = cantidad_habitaciones;
            this.cantidad_baños = cantidad_baños;
            this.estado_registro = estado_registro;
            this.edificio = edificio;
        }

        public ModeloDepartamento()
        {

        }

    }
}
