﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class ModeloUsuario
    {

        public int id_usuario { get; set; }
        public int rut { get; set; }
        public string dv { get; set; }
        public string nombre { get; set; }
        public string ap_paterno { get; set; }
        public string ap_materno { get; set; }
        public string email { get; set; }
        public int telefono { get; set; }
        public string region { get; set; }
        public string comuna { get; set; }
        public string direccion { get; set; }
        public DateTime fch_nacimiento { get; set; }
        public int estado { get; set; }
        public string usuario { get; set; }
        public string contraseña { get; set; }
        public int id_rol { get; set; }

        public ModeloUsuario(int id_usuario, int rut, string dv, string nombre, string ap_paterno, string ap_materno, string email, int telefono, string region, string comuna, string direccion, DateTime fch_nacimiento, int estado, string usuario, string contraseña, int id_rol)
        {
            this.id_usuario = id_usuario;
            this.rut = rut;
            this.dv = dv;
            this.nombre = nombre;
            this.ap_paterno = ap_paterno;
            this.ap_materno = ap_materno;
            this.email = email;
            this.telefono = telefono;
            this.region = region;
            this.comuna = comuna;
            this.direccion = direccion;
            this.fch_nacimiento = fch_nacimiento;
            this.estado = estado;
            this.usuario = usuario;
            this.contraseña = contraseña;
            this.id_rol = id_rol;
        }

        public ModeloUsuario(int id_usuario, int rut, string dv, string nombre, string ap_paterno, string ap_materno, string email, int telefono, string region, string comuna, string direccion, DateTime fch_nacimiento, int estado, string usuario, string contraseña)
        {
            this.id_usuario = id_usuario;
            this.rut = rut;
            this.dv = dv;
            this.nombre = nombre;
            this.ap_paterno = ap_paterno;
            this.ap_materno = ap_materno;
            this.email = email;
            this.telefono = telefono;
            this.region = region;
            this.comuna = comuna;
            this.direccion = direccion;
            this.fch_nacimiento = fch_nacimiento;
            this.estado = estado;
            this.usuario = usuario;
            this.contraseña = contraseña;
        }

        public ModeloUsuario()
        {
        }
    }
}
