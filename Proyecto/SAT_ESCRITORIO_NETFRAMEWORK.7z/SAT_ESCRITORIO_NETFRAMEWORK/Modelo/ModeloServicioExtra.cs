﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class ModeloServicioExtra
    {
        
        public int idServicio { get; set; }
        public string nombreServicio { get; set; }
        public int costoServicio { get; set; }
        public string descripcion { get; set; }
        public int estado { get; set; }

        public ModeloServicioExtra(int idServicio, string nombreServicio, int costoServicio, string descripcion, int estado)
        {
            this.idServicio = idServicio;
            this.nombreServicio = nombreServicio;
            this.costoServicio = costoServicio;
            this.descripcion = descripcion;
            this.estado = estado;
        }

        public ModeloServicioExtra()
        {
        }
    }
}
