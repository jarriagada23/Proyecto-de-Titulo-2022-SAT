﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class ModeloEdificio
    {
        public int id_edificio { get; set; }
        public string nombre_edificio { get; set; }
        public string region { get; set; }
        public string comuna { get; set; }
        public string direccion { get; set; }
        public int cantidad_pisos { get; set; }
        public int registro_activo { get; set; }

        public ModeloEdificio(int id_edificio, string nombre_edificio, string region, string comuna, string direccion, int cantidad_pisos, int registro_activo)
        {
            this.id_edificio = id_edificio;
            this.nombre_edificio = nombre_edificio;
            this.region = region;
            this.comuna = comuna;
            this.direccion = direccion;
            this.cantidad_pisos = cantidad_pisos;
            this.registro_activo = registro_activo;
        }

        public ModeloEdificio()
        {

        }

        public ModeloEdificio(int id_edificio, string nombre_edificio)
        {
            this.id_edificio = id_edificio;
            this.nombre_edificio = nombre_edificio;
        }
    }
}
