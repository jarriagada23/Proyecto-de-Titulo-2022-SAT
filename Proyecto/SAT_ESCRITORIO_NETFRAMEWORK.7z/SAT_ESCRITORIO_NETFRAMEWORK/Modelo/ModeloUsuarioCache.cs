﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public static class ModeloUsuarioCache
    {
        public static int id_usuario { get; set; }

        public static string nombre { get; set; }
        public static string ap_paterno { get; set; }
        public static string ap_materno { get; set; }
        public static string email { get; set; }
        public static string usuario { get; set; }
        public static string contraseña { get; set; }
        public static int id_rol { get; set; }
    }
}
